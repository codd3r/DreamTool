import requests

codein = "prcenter"
while True:
	why = input("[1] Reg\n  - ")
	if why == "1":
		login, password, code = input("Login: ").lower(), input("Password: ").lower(), codein
		requests.get(f"http://185.212.148.226:5010/register?v=1.2&login={login}&password={password}&admin={code}")
