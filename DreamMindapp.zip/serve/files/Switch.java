package il2cpp.typefaces;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import il2cpp.Utils;
import java.util.concurrent.BlockingDeque;

public class CheckBox extends LinearLayout {
	Context context;
	
	public android.widget.Switch button;
	public TextView title;
	public Callback callback;
	
	String graycolor = "#3C3C3C",
		   bluecolor = "#0456DF";
	
	public static interface Callback {
		public void onChanged(boolean checked);
	}

	public void setCallback(Callback call) {
		callback = call;
	}
	public boolean isChecked = false;
	public void setChecked(boolean check) {
		isChecked = check;
		if (callback != null) callback.onChanged(button.isChecked());
		if (isChecked){
			GradientDrawable grad2 = new GradientDrawable();
			grad2.setColor(Color.parseColor(bluecolor));
			grad2.setCornerRadius(50f);
			button.setTrackDrawable(grad2);
			button.setChecked(true);
		} else {
			GradientDrawable grad2 = new GradientDrawable();
			grad2.setColor(Color.parseColor(graycolor));
			grad2.setCornerRadius(50f);
			button.setTrackDrawable(grad2);
			button.setChecked(false);
		}
		Utils.anim(button, 450);
	}
	
	public void setText(String text) {
		title.setText(text);
	}
	
	public CheckBox(Context ctx) {
		super(ctx);
		context = ctx;
		
		setOrientation(LinearLayout.HORIZONTAL);
		setLayoutParams(new LayoutParams(-1, Utils.dp(context, 20)));
		setGravity(Gravity.CENTER_VERTICAL);
		//setPadding(10, 0, 10, 0);
		
		title = new TextView(context);
		{
			title.setTextSize(10.5f);
			title.setTextColor(Color.WHITE);
			title.setTypeface(Utils.font(context));
			title.setGravity(Gravity.CENTER_VERTICAL);
			title.setPadding(15, 0, 0, 0);
			
			addView(title, new LayoutParams(-1, -1, 1));
		}
		
		button = new android.widget.Switch(context);
		{
			GradientDrawable grad = new GradientDrawable();
			grad.setColor(Color.parseColor(bluecolor));
			grad.setStroke(5, Color.parseColor(graycolor));
			grad.setCornerRadius(50f);
			grad.setSize(Utils.dp(context, 15), Utils.dp(context, 15));
			
			button.setThumbDrawable(grad);
			
			GradientDrawable grad2 = new GradientDrawable();
			grad2.setColor(Color.parseColor(graycolor));
			grad2.setCornerRadius(50f);
			button.setTrackDrawable(grad2);
			
			addView(button, -2, -2);
			//setBackgroundColor(Color.RED);
			
			button.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				public void onCheckedChanged(CompoundButton g, boolean check) {
					setChecked(check);
				}
			});
		}
	}
}
