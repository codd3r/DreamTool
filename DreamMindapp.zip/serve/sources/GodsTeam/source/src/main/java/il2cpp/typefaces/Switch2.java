package il2cpp.typefaces;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import il2cpp.Utils;

public class Switch2 extends LinearLayout {
	Context context;
	
	public android.widget.Switch button;
	public TextView title;
	public Callback callback;
	
	public static interface Callback {
		public void onChange();
	}

	public void setCallback(Callback call) {
		callback = call;
	}
	public boolean isChecked = false;
	public void setChecked(boolean check) {
		isChecked = check;
		if (callback != null) callback.onChange();
		Utils.anim(button, 450);
	}
	
	public Switch2(Context ctx, String name) {
		super(ctx);
		context = ctx;
		
		setOrientation(LinearLayout.HORIZONTAL);
		setLayoutParams(new LayoutParams(-1, Utils.dp(context, 30)));
		setGravity(Gravity.CENTER_VERTICAL);
		setPadding(0, 0, 20, 0);
		
		title = new TextView(context);
		{
			title.setText(name);
			title.setTextSize(14.5f);
			title.setTextColor(Color.BLACK);
			title.setTypeface(Utils.font(context));
			title.setGravity(Gravity.CENTER_VERTICAL);
			title.setPadding(25, 0, 0, 0);
			
			addView(title, new LayoutParams(-1, -1, 1));
		}
		
		button = new android.widget.Switch(context);
		{
			GradientDrawable grad = new GradientDrawable();
			grad.setColor(Color.parseColor(MenuColors.switchbutton));
			grad.setStroke(2, Color.parseColor(MenuColors.blue));
			grad.setCornerRadius(50f);
			grad.setSize(Utils.dp(context, 15), Utils.dp(context, 15));
			
			button.setThumbDrawable(grad);
			
			GradientDrawable grad2 = new GradientDrawable();
			grad2.setColor(Color.WHITE);
			grad2.setCornerRadius(50f);
			button.setTrackDrawable(grad2);
			
			addView(button, -2, -2);
			//setBackgroundColor(Color.RED);
			
			button.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				public void onCheckedChanged(CompoundButton g, boolean check) {
					setChecked(check);
				}
			});
			
			GradientDrawable gr = new GradientDrawable();
			gr.setStroke(2, Color.parseColor(MenuColors.switchbutton));
			setBackgroundDrawable(gr);
		}
	}
}
