package il2cpp.typefaces;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.view.inputmethod.InputMethodManager;
import il2cpp.*;
import android.text.*;
import android.view.Window.*; 
import android.text.method.*;
import android.graphics.Typeface;
import android.util.*;
import android.view.*;
import android.widget.*;
import android.view.animation.AlphaAnimation; 
import android.view.animation.Animation;
import java.io.*;
import java.util.Objects;
import android.widget.LinearLayout.LayoutParams;
import android.support.v7.widget.CardView;
import java.util.ArrayList;
import android.view.View.OnClickListener;

class MenuColors {
	public static String main = "#3C4645";
	public static String gray = "#D7D7D7";
	public static String switchbutton = "#B2B3B3";
	public static String blue = "#91B1CD";
	
}

class Pagebutton extends LinearLayout{
	Context context;
	public ImageView icon;
	public boolean isChecked = false;
	public LinearLayout line;
	
	public void setChecked(boolean check) {
		isChecked = check;
		int color1 = 0;
		int color2 = 0;
		if (isChecked) {
			color1 = Color.parseColor(MenuColors.blue);
			color2 = Color.WHITE;
		} else {
			color2 = Color.parseColor(MenuColors.blue);
			color1 = Color.WHITE;
		}
		GradientDrawable grad = new GradientDrawable();
		grad.setCornerRadii(new float[] {20,20,20,20,0,0,0,0});
		grad.setColor(color1);
		grad.setStroke(3, color2);
		line.setBackgroundDrawable(grad);
	}
	
	public static interface Callback {
		public void onClick();
	}
	public Callback callback;
	public void setCallback(Callback callback) {
		this.callback = callback;
	}
	
	public void Click() {
		if (callback != null) callback.onClick();
	}
	
	public Pagebutton(Context context, String src) {
		super(context);
		this.context = context;
		
		line = new LinearLayout(context);
		
		icon = new ImageView(context);
		{
			Utils.SetAssets(context, icon, src);
			icon.setColorFilter(Color.BLACK);
			
			icon.setPadding(10,10,10,10);
			line.addView(icon, -1, -1);
		}
		
		setLayoutParams(new LayoutParams(Utils.dp(context, 45), Utils.dp(context, 40)));
		addView(line, -1, -1);
		setPadding(5, 0, 5, 0);
		setChecked(false);
		
		setOnClickListener(new OnClickListener() {
			public void onClick(View v){
				Click();
			}
		});
	}
}

public class Menu
{
	protected int WIDTH,HEIGHT;
    
	public Typeface google(Context yes) {return Typeface.createFromAsset(yes.getAssets(), "Font.ttf");}
	
	protected Context context;
	protected FrameLayout parentBox;
	protected LinearLayout menulayout;  
	public LinearLayout header, mainlayout, bottom, buttons, page;
	public TextView title, gametitle;
	public ImageView gameicon, icon;
	public ScrollView scroll;
	boolean isShow = false;
	
	public ArrayList<Pagebutton> buttonList = new ArrayList<>();
	public ArrayList<LinearLayout> pages = new ArrayList<>();
	
	protected WindowManager wmManager;
	protected WindowManager.LayoutParams wmParams;
	
	protected void init(Context context) {
		
		this.context = context;
		
		parentBox = new FrameLayout(context);

		parentBox.setOnTouchListener(handleMotionTouch);
		wmManager = ((Activity)context).getWindowManager();
		int aditionalFlags=0;
		if (Build.VERSION.SDK_INT >= 11)
			aditionalFlags = WindowManager.LayoutParams.FLAG_SPLIT_TOUCH;
		if (Build.VERSION.SDK_INT >=  3)
			aditionalFlags = aditionalFlags | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM;
		wmParams = new WindowManager.LayoutParams(
			WindowManager.LayoutParams.WRAP_CONTENT,
			WindowManager.LayoutParams.WRAP_CONTENT,
			0,//initialX
			0,//initialy
			WindowManager.LayoutParams.TYPE_APPLICATION,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
			WindowManager.LayoutParams.FLAG_LAYOUT_IN_OVERSCAN |
			WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
			aditionalFlags,
			PixelFormat.TRANSPARENT
		);
		wmParams.gravity = Gravity.CENTER;
	}
	
	public int dpi(float dp) {
		float scale = context.getResources().getDisplayMetrics().density;
		return (int) (dp * scale + 0.5f);
	}
	
	public void showMenu() {
		isShow = true;
		parentBox.removeAllViews();
		parentBox.addView(menulayout, WIDTH, HEIGHT);
		ObjectAnimator scaleDown = ObjectAnimator.ofPropertyValuesHolder(menulayout, 
																		 PropertyValuesHolder.ofFloat("scaleX", 0f, 1.0f),
																		 PropertyValuesHolder.ofFloat("scaleY", 0f, 1.0f));															 PropertyValuesHolder.ofFloat("scaleY", 0f, 1.0f);
		scaleDown.setDuration(350);
		scaleDown.start();
	}

	public void hideMenu() {
		isShow = false;
		ObjectAnimator scaleDown = ObjectAnimator.ofPropertyValuesHolder(menulayout, 
																		 PropertyValuesHolder.ofFloat("scaleX", 1.0f, 0f),
																		 PropertyValuesHolder.ofFloat("scaleY", 1.0f, 0f));
		scaleDown.setDuration(350);
		scaleDown.start();
		new Handler().postDelayed(new Runnable() {
			public void run() {
				parentBox.removeAllViews();
				parentBox.addView(icon, dpi(50), dpi(50));
				Utils.anim(icon, 200);
			}
		}, 350);
	}
	
	public void newPage(String name, String src) {
		final int pageid = buttonList.size();
		
		Pagebutton button = new Pagebutton(context, src);
		button.setCallback(new Pagebutton.Callback() {
			public void onClick() {
				showPage(pageid);
			}
		});
		button.setTranslationY(5);
		buttonList.add(button);
		buttons.addView(button);
		
		LinearLayout pagenew = new LinearLayout(context);
		pagenew.setGravity(Gravity.CENTER_HORIZONTAL);
		pagenew.setOrientation(LinearLayout.VERTICAL);
		pagenew.setVisibility(View.GONE);
		
		TextView title = new TextView(context);
		title.setText(name);
		title.setTextColor(Color.BLACK);
		title.setTextSize(13f);
		title.setGravity(Gravity.CENTER);
		title.setTypeface(google(context));
		
		GradientDrawable grad = new GradientDrawable();
		grad.setColor(Color.WHITE);
		grad.setStroke(2, Color.parseColor(MenuColors.switchbutton));
		grad.setCornerRadii(new float[] {20,20,20,20,0,0,0,0});
		title.setBackgroundDrawable(grad);
		
		pagenew.addView(title, -1, Utils.dp(context, 30));
		
		pages.add(pagenew);
		page.addView(pagenew, -1, -1);
	}
	
	public void showPage(int id) {
		for (Pagebutton butt: buttonList) {
			butt.setChecked(false);
		}
		buttonList.get(id).setChecked(true);
		Utils.anim(buttonList.get(id).icon, 400);
		
		for (LinearLayout paged: pages) {
			paged.setVisibility(View.GONE);
		}
		pages.get(id).setVisibility(View.VISIBLE);
		Utils.anim(pages.get(id), 400);
	}
	
	public void newSwitch(int pageid, String text, final int featu) {
		Switch2 sw = new Switch2(context, text);
		pages.get(pageid).addView(sw);
		sw.setCallback(new Switch2.Callback() {
			public void onChange() {
				Main.Changes(featu, 0);
			}
		});
	}
	
	public Menu(Context context)
	{
		init(context);

		WIDTH = dpi(400);
		HEIGHT = dpi(300);
		
		icon = new ImageView(context);
		Utils.SetAssets(context, icon, "icon.png");
		
		menulayout = new LinearLayout(context);
		menulayout.setOrientation(LinearLayout.VERTICAL);
		
		{
			GradientDrawable grad = new GradientDrawable();
			grad.setColor(Color.parseColor(MenuColors.main));
			grad.setCornerRadius(15f);
			menulayout.setBackgroundDrawable(grad);
		}
		
		header = new LinearLayout(context);
		{
			header.setOrientation(LinearLayout.HORIZONTAL);
			header.setGravity(Gravity.LEFT);
			
			title = new TextView(context);
			{
				title.setText("GodsTeam");
				title.setTextSize(13f);
				title.setTextColor(Color.WHITE);
				title.setGravity(Gravity. CENTER_VERTICAL);
				title.setPadding(50, 0, 0, 0);
				title.setTypeface(google(context));
				
				header.addView(title, new LayoutParams(-2, -1));
			}
			menulayout.addView(header, -1, Utils.dp(context, 45));
			
			buttons = new LinearLayout(context);
			{
				buttons.setOrientation(LinearLayout.HORIZONTAL);
				buttons.setGravity(Gravity.RIGHT | Gravity.BOTTOM);
				buttons.setPadding(0, 0, 40, 0);
			}
			
			header.addView(buttons, new LayoutParams(-1, -1, 1));
		}
		
		mainlayout = new LinearLayout(context);
		{
			mainlayout.setOrientation(LinearLayout.VERTICAL);
			mainlayout.setPadding(20, 0, 20, 0);
			
			LinearLayout stroke = new LinearLayout(context);
			GradientDrawable grad = new GradientDrawable();
			grad.setColor(Color.parseColor(MenuColors.blue));
			grad.setCornerRadius(25f);
			stroke.setBackgroundDrawable(grad);
			stroke.setPadding(5,5,5,5);
			
			scroll = new ScrollView(context);
			{
				CardView card = new CardView(context);
				page = new LinearLayout(context);
				page.setBackgroundColor(Color.parseColor(MenuColors.gray));
				
				scroll.setFillViewport(true);
				
				card.setRadius(20f);
				card.addView(scroll, -1, -1);
				scroll.addView(page, -1, -1);
				
				stroke.addView(card, -1, -1);
				mainlayout.addView(stroke, -1, -1);
			}
			
			mainlayout.setLayoutParams(new LayoutParams(-1, Utils.dp(context, 210)));
			menulayout.addView(mainlayout);
			
		}
		
		bottom = new LinearLayout(context);
		{
			bottom.setOrientation(LinearLayout.HORIZONTAL);
			bottom.setGravity(Gravity.LEFT);
			bottom.setPadding(5,5,10,5);
			
			gameicon = new ImageView(context);
			gameicon.setPadding(15,10,10,10);
			Utils.SetAssets(context, gameicon, "game.png");
			
			gametitle = new TextView(context);
			{
				gametitle.setText("Free Fire v1.66.81");
				gametitle.setTextSize(13f);
				gametitle.setTextColor(Color.WHITE);
				gametitle.setGravity(Gravity.CENTER_VERTICAL);
				gametitle.setPadding(25, 0, 0, 0);
				gametitle.setTypeface(google(context));
			}
			
			Button close = new Button(context);
			{
				GradientDrawable grad = new GradientDrawable();
				grad.setColor(Color.parseColor("#FFFFFF"));
				grad.setStroke(4, Color.parseColor(MenuColors.blue));
				grad.setCornerRadii(new float[]{15, 15, 5, 5, 5, 5, 5, 5});
				close.setBackgroundDrawable(grad);
				
				close.setText("Close");
				close.setTextSize(13f);
				close.setTextColor(Color.BLACK);
				close.setTypeface(google(context));
				close.setOnClickListener(new OnClickListener() {
					public void onClick(View v) {
						hideMenu();
					}
				});
			}
			
			newPage("test", "icon1.png");
			newPage("testjdhd", "icon1.png");
			
			newSwitch(0, "Test", 0);
			newSwitch(0, "Aim", 1);
			
			newSwitch(1, "hasjd", 2);
			newSwitch(1, "sheuue", 3);
			
			showPage(0);
			
			bottom.addView(gameicon, Utils.dp(context, 40), -1);
			bottom.addView(gametitle, new LayoutParams(-1, -1, 1));
			
			LayoutParams lp = new LayoutParams(Utils.dp(context, 90), -1);
			lp.setMargins(0, 7, 15, 7);
			bottom.addView(close, lp);
			
			menulayout.addView(bottom, new LayoutParams(-1, Utils.dp(context, 45)));
		}
		
		hideMenu();
		wmManager.addView(parentBox, wmParams);
	}
	
	View.OnTouchListener handleMotionTouch = new View.OnTouchListener()
	{
		private float initX;          
		private float initY;
		private float touchX;
		private float touchY;

		double clock=0;
		
		@Override
		public boolean onTouch(View vw, MotionEvent ev)
		{

			switch (ev.getAction())
			{
				case MotionEvent.ACTION_DOWN:

					initX = wmParams.x;
					initY = wmParams.y;
					touchX = ev.getRawX();
					touchY = ev.getRawY();
					clock = System.currentTimeMillis();
					break;

				case MotionEvent.ACTION_MOVE:
					wmParams.x = (int)initX + (int)(ev.getRawX() - touchX);

					wmParams.y = (int)initY + (int)(ev.getRawY() - touchY);


					wmManager.updateViewLayout(vw, wmParams);
					break;

				case MotionEvent.ACTION_UP:
					if (!isShow && (System.currentTimeMillis() < (clock + 200)))
					{
						showMenu();
					}
					break;
			}
			return true;
		}
	};
}
