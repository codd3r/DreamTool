package Weave.menu;
import Weave.Utils;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.ImageView;

class AlertPicker extends Dialog {
	Context context;
	
	LinearLayout mainlayout, buttons;
	ScrollView scrl;
	
	public Callback callback;
	
	public void setCallback(Callback call) {
		callback = call;
	}
	
	public static interface Callback {
		public void onPick(int idx, String name);
	}
	
	public void pick(int idx, String name) {
		if (callback != null) callback.onPick(idx, name);
	}
	
	public AlertPicker(Context ctx, final String[] names) {
		super(ctx);
		context = ctx;
		
		mainlayout = new LinearLayout(context);
		{ // Main layout
			mainlayout.setOrientation(LinearLayout.VERTICAL);
			
			GradientDrawable grad = new GradientDrawable();
			grad.setCornerRadius(5f);
			grad.setColor(ColorList.colorMain());
			mainlayout.setBackgroundDrawable(grad);
			
			scrl = new ScrollView(context);
			buttons = new LinearLayout(context);
			{ // Buttons layout in scroll
				scrl.addView(buttons, -1, -1);
				buttons.setOrientation(LinearLayout.VERTICAL);
			}
			mainlayout.addView(scrl, -1, -1);
			
			for (int i = 0; i < names.length; i++) {
				final WeaveButton button = new WeaveButton(context, names[i]);
				final int index = i;
				button.setCallback(new WeaveButton.Callback() {
					public void onClick() {
						pick(index, names[index]);
						dismiss();
					}
				});
				button.button.setTextSize(17f);
				buttons.addView(button, Utils.dp(context, 350), Utils.dp(context, 50));
			}
			
			setContentView(mainlayout);
		}
	}
	
	public void showPicker() {
		show();
	}
}

public class WeaveSpinner extends LinearLayout {
	Context context;
	
	public LinearLayout background;
	public TextView title;
	public ImageView img;

	public static interface Callback {
		public void onPut(String text, int idx);
	}
	public Callback callback;

	public void setCallback(Callback call) {
		callback = call;
	}

	public void setValue(String text, int id) {
		if (text.length() > 15) {
			title.setText(text.substring(0, 15));
		} else {
			title.setText(text);
		}
		if (callback != null) callback.onPut(text, id);
	}

	public WeaveSpinner(Context ctx, final String[] texts) {
		super(ctx);
		context = ctx;

		background = new LinearLayout(context);
		background.setOrientation(LinearLayout.HORIZONTAL);
		{ // Background input
			GradientDrawable back = new GradientDrawable();
			back.setColor(ColorList.colorMain());
			back.setStroke(3, ColorList.colorHeader());

			background.setPadding(0,0,10,0);
			background.setGravity(Gravity.CENTER_VERTICAL);
			background.setBackgroundDrawable(back);
		}

		title = new TextView(context);
		{ // Text value
			title.setText("...");
			title.setTextSize(11.5f);
			title.setTypeface(Utils.font(context));
			title.setTextColor(Color.WHITE);
			title.setGravity(Gravity.CENTER_VERTICAL);
			title.setPadding(20,0,0,0);

			
		}
		
		img = new ImageView(context);
		{ // arrow
			Utils.SetAssets(context, img, "arrow.png");
			img.setPadding(10, 10, 10, 10);
			img.setRotation(90);
			img.setColorFilter(Color.WHITE);
		}
		
		background.addView(title, new LayoutParams(-1, -1, 1));
		background.addView(img, Utils.dp(context, 20), Utils.dp(context, 20));
		
		addView(background, -1, -1);

		setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				AlertPicker dlg = new AlertPicker(context, texts);
				dlg.setCallback(new AlertPicker.Callback() {
					public void onPick(int idx, String txt) {
						setValue(txt, idx);
					}
				});
				dlg.showPicker();
			}
		});
		
		setLayoutParams(new LinearLayout.LayoutParams(-1, Menu.dp(context, 30)));
		setPadding(10, 10, 10, 10);
	}
}
