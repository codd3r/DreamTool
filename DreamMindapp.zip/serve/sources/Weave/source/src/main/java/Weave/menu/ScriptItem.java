package Weave.menu;
import Weave.Utils;
import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.File;

public class ScriptItem extends LinearLayout {
	Context context;
	
	public LinearLayout line;
	public TextView title;
	
	public int mainColor;
	public String name;
	public File script;
	
	public boolean isSelect = false;
	
	public static interface Callback {
		public void onClick(String name, File file);
	}
	public Callback callback;
	public void setCallback(Callback call) {
		callback = call;
	}
	
	public void select() {
		if (callback != null) {
			callback.onClick(name, script);
		}
	}
	
	public ScriptItem(Context ctx, String namesript, File filescript) {
		super(ctx);
		context = ctx;
		name = namesript;
		script = filescript;
		
		mainColor = ColorList.colorOrange();
		
		setOrientation(LinearLayout.HORIZONTAL);
		setLayoutParams(new LayoutParams(-1, Utils.dp(context, 20)));
		
		line = new LinearLayout(context);
		{ // Line design
			line.setBackgroundColor(Color.TRANSPARENT);
		}
		
		title = new TextView(context);
		{ // Title design
			title.setText(name);
			title.setTextSize(11.5f);
			title.setTypeface(Utils.font(context));
			title.setTextColor(Color.WHITE);
			title.setGravity(Gravity.CENTER_VERTICAL);
			title.setPadding(20,0,0,0);
		}
		
		addView(line, Utils.dp(context, 2), -1);
		addView(title, -1, -1);
		
		setOnClickListener(new OnClickListener() {
			public void onClick(View v){
				select();
			}
		});
	}
}
