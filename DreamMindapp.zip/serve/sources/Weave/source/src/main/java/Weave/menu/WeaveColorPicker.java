package Weave.menu;

import Weave.Utils;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ComposeShader;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.drawable.GradientDrawable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Spinner;

class ColorPicker extends View
 { 
    private int alphaVal = 255; 
    private float[] colorHSV = new float[]{0.0f, 0.0f, 1.0f}; 
    private Paint colorPointerPaint; 
    private int colorPointerRad = this.dpToPixels(5); 
    private Bitmap colorWheelBitmap; 
    private Paint colorWheelPaint; 
    private int colorWheelRadius; 
    ColorChangedListener mColorChangedListener; 
    private int padding = this.dpToPixels(10); 

    public ColorPicker(Context context) { 
        super(context); 
        this.init(); 
    } 

    public ColorPicker(Context context, AttributeSet attributeSet) { 
        super(context, attributeSet); 
        this.init(); 
    } 

    public ColorPicker(Context context, AttributeSet attributeSet, int n) { 
        super(context, attributeSet, n); 
        this.init(); 
    } 

    private Bitmap createColorWheelBitmap(int n) { 
        if (n < 1) { 
            return Bitmap.createBitmap((int)1, (int)1, (Bitmap.Config)Bitmap.Config.ARGB_8888); 
        } 
        Bitmap bitmap = Bitmap.createBitmap((int)n, (int)n, (Bitmap.Config)Bitmap.Config.ARGB_8888); 
        int[] arrn = new int[13]; 
        float[] arrf = new float[]{0.0f, 1.0f, 1.0f}; 
        for (int i = 0; i < arrn.length; ++i) { 
            arrf[0] = (180 + i * 30) % 360; 
            arrn[i] = Color.HSVToColor((float[])arrf); 
        } 
        arrn[12] = arrn[0]; 
        float f2 = n / 2; 
        SweepGradient sweepGradient = new SweepGradient(f2, f2, arrn, null); 
        RadialGradient radialGradient = new RadialGradient(f2, f2, (float)this.colorWheelRadius, -1, 16777215, Shader.TileMode.CLAMP); 
        ComposeShader composeShader = new ComposeShader((Shader)sweepGradient, (Shader)radialGradient, PorterDuff.Mode.SRC_OVER); 
        this.colorWheelPaint.setShader((Shader)composeShader); 
        new Canvas(bitmap).drawCircle(f2, f2, (float)this.colorWheelRadius, this.colorWheelPaint); 
        return bitmap; 
    } 

    private void init() { 
        this.colorPointerPaint = new Paint(1); 
        this.colorPointerPaint.setDither(true); 
        this.colorPointerPaint.setStyle(Paint.Style.STROKE); 
        this.colorPointerPaint.setStrokeWidth((float)this.dpToPixels(2)); 
        this.colorPointerPaint.setARGB(128, 0, 0, 0); 
        this.colorWheelPaint = new Paint(); 
        this.colorWheelPaint.setAntiAlias(true); 
        this.colorWheelPaint.setDither(true); 
        this.colorWheelPaint.setFilterBitmap(true); 
    } 

    int dpToPixels(int n) { 
        Resources resources = this.getResources(); 
        return (int)TypedValue.applyDimension((int)1, (float)n, (DisplayMetrics)resources.getDisplayMetrics()); 
    } 

    public int getAlphaVal() { 
        return this.alphaVal; 
    } 

    public int getColor() { 
        return Color.HSVToColor((int)this.alphaVal, (float[])this.colorHSV); 
    } 

    public float[] getColorHSV() { 
        return this.colorHSV; 
    } 

    public float getSaturation() { 
        return this.colorHSV[1]; 
    } 

    public float getValue() { 
        return this.colorHSV[2]; 
    } 

    @SuppressLint(value={"DrawAllocation"}) 
    protected void onDraw(Canvas canvas) { 
        if (this.colorWheelBitmap.getWidth() < 4) { 
            return; 
        } 
        float f2 = (float)this.getWidth() / 2.0f; 
        float f3 = (float)this.getHeight() / 2.0f; 
        Bitmap bitmap = this.colorWheelBitmap; 
        int n = this.colorWheelRadius; 
        canvas.drawBitmap(bitmap, f2 - (float)n, f3 - (float)n, this.colorWheelPaint); 
        canvas.drawCircle(f2, f3, (float)this.colorWheelRadius, this.colorPointerPaint); 
        double d2 = (float)Math.toRadians((double)this.colorHSV[0]); 
        double d3 = -Math.cos((double)d2); 
        double d4 = this.colorHSV[1]; 
        Double.isNaN((double)d4); 
        double d5 = d3 * d4; 
        double d6 = this.colorWheelRadius; 
        Double.isNaN((double)d6); 
        double d7 = d5 * d6; 
        double d8 = f2; 
        Double.isNaN((double)d8); 
        float f4 = (float)(d7 + d8); 
        double d9 = -Math.sin((double)d2); 
        double d10 = this.colorHSV[1]; 
        Double.isNaN((double)d10); 
        double d11 = d9 * d10; 
        double d12 = this.colorWheelRadius; 
        Double.isNaN((double)d12); 
        double d13 = d11 * d12; 
        double d14 = f3; 
        Double.isNaN((double)d14); 
        canvas.drawCircle(f4, (float)(d13 + d14), (float)this.colorPointerRad, this.colorPointerPaint); 
    } 

    protected void onMeasure(int n, int n2) { 
        int n3 = Math.min((int)View.MeasureSpec.getSize((int)n), (int)View.MeasureSpec.getSize((int)n2)); 
        this.setMeasuredDimension(n3, n3); 
    } 

    protected void onSizeChanged(int n, int n2, int n3, int n4) { 
        this.colorWheelRadius = n / 2 - this.padding; 
        this.colorWheelBitmap = this.createColorWheelBitmap(2 * this.colorWheelRadius); 
    } 

    public boolean onTouchEvent(MotionEvent motionEvent) { 
        float f2; 
        int n = motionEvent.getAction(); 
        if (n != 0 && n != 2) { 
            return super.onTouchEvent(motionEvent); 
        } 
        float f3 = motionEvent.getX(); 
        float f4 = motionEvent.getY(); 
        float f5 = f3 - (float)(this.getWidth() / 2); 
        double d2 = Math.sqrt((double)(f5 * f5 + (f2 = f4 - (float)(this.getHeight() / 2)) * f2)); 
        if (d2 <= (double)this.colorWheelRadius) { 
            this.colorHSV[0] = (float)(180.0 + Math.toDegrees((double)Math.atan2((double)f2, (double)f5))); 
            float[] arrf = this.colorHSV; 
            double d3 = this.colorWheelRadius; 
            Double.isNaN((double)d3); 
            arrf[1] = Math.max((float)0.0f, (float)Math.min((float)1.0f, (float)((float)(d2 / d3)))); 
            ColorChangedListener colorChangedListener = this.mColorChangedListener; 
            if (colorChangedListener != null) { 
                colorChangedListener.colorChange(); 
            } 
            this.invalidate(); 
        } 
        return true; 
    } 

    public void setAlphaVal(int n) { 
        this.alphaVal = n; 
        ColorChangedListener colorChangedListener = this.mColorChangedListener; 
        if (colorChangedListener != null) { 
            colorChangedListener.colorChange(); 
        } 
        this.invalidate(); 
    } 

    public void setBlue(int n) { 
        int n2 = this.getColor(); 
        this.setColor(Color.rgb((int)Color.red((int)n2), (int)Color.green((int)n2), (int)n)); 
    } 

    public void setColor(int n) { 
        this.setColor(n, this.alphaVal); 
    } 

    public void setColor(int n, int n2) { 
        Color.colorToHSV((int)n, (float[])this.colorHSV); 
        this.setAlphaVal(n2); 
        ColorChangedListener colorChangedListener = this.mColorChangedListener; 
        if (colorChangedListener != null) { 
            colorChangedListener.colorChange(); 
        } 
        this.invalidate(); 
    } 

    public void setGreen(int n) { 
        int n2 = this.getColor(); 
        this.setColor(Color.rgb((int)Color.red((int)n2), (int)n, (int)Color.blue((int)n2))); 
    } 

    public void setOnColorChangedListener(ColorChangedListener colorChangedListener) { 
        this.mColorChangedListener = colorChangedListener; 
    } 

    public void setRed(int n) { 
        int n2 = this.getColor(); 
        this.setColor(Color.rgb((int)n, (int)Color.green((int)n2), (int)Color.blue((int)n2))); 
    } 

    public void setSaturation(float f2) { 
        this.colorHSV[1] = f2; 
        ColorChangedListener colorChangedListener = this.mColorChangedListener; 
        if (colorChangedListener != null) { 
            colorChangedListener.colorChange(); 
        } 
        this.invalidate(); 
    } 

    public void setValue(float f2) { 
        this.colorHSV[2] = f2; 
        ColorChangedListener colorChangedListener = this.mColorChangedListener; 
        if (colorChangedListener != null) { 
            colorChangedListener.colorChange(); 
        } 
        this.invalidate(); 
    } 

    public static interface ColorChangedListener { 
        public void colorChange(); 
    } 

} 

class DialogPicker extends Dialog {
	Context context;
	public static interface Callback {
		public void onPick(int c);
	}
	public Callback callback;
	
	public DialogPicker(Context ctx, Callback call) {
		super(ctx);
		context = ctx;
		callback = call;
		
		final ColorPicker cp = new ColorPicker(context);
		final LinearLayout layout = new LinearLayout(context);
		layout.addView(cp, Menu.dp(context, 300), Menu.dp(context, 300));
		
		setContentView(layout);
		
		layout.setGravity(Gravity.CENTER);
		layout.setOrientation(LinearLayout.VERTICAL);

		WeaveButton enter = new WeaveButton(context, "Enter");
		
		layout.addView(enter, Menu.dp(context, 300), Menu.dp(context, 50));
		
		GradientDrawable layoutdesign = new GradientDrawable();
		layoutdesign.setColor(ColorList.colorMain());
		
		getWindow().setBackgroundDrawable(layoutdesign);

		enter.setCallback(new WeaveButton.Callback() {
			public void onClick() {
				dismiss();
				callback.onPick(cp.getColor());
			}
		});
		show();
	}
}

public class WeaveColorPicker extends LinearLayout {
	Context context;
	
	LinearLayout expand, picker;
	TextView title;
	
	public static interface Callback {
		public void onPick(int c);
	}
	public Callback callback;
	public void setCallback(Callback call) {
		callback = call;
	}
	
	public void setColor(int c) {
		int darkness = 100;
		int red = Color.red(c) - darkness;
		if (red < 0) red = 0;
		int green = Color.green(c) - darkness;
		if (green < 0) green = 0;
		int blue = Color.blue(c) - darkness;
		if (blue < 0) blue = 0;
		
		GradientDrawable pick = new GradientDrawable(
			GradientDrawable.Orientation.BOTTOM_TOP,
			new int[] {Color.rgb(red, green, blue), c}
		);
		pick.setCornerRadius(5f);
		pick.setStroke(2, Color.WHITE);
		
		picker.setBackgroundDrawable(pick);
		if (callback != null) callback.onPick(c);
	}
	
	public WeaveColorPicker(Context ctx, String text) {
		super(ctx);
		context = ctx;
		
		picker = new LinearLayout(context);
		{ // Cube color picker
			setColor(Color.WHITE);
		}
		
		expand = new LinearLayout(context);
		{ // Expand line
			expand.setPadding(10, 10, 10, 10);
			expand.setGravity(Gravity.CENTER);
			
			expand.addView(picker, -1, -1);
		}
		
		title = new TextView(context);
		{ // Picker text
			title.setText(text);
			title.setTextSize(11.5f);
			title.setTypeface(Utils.font(context));
			title.setTextColor(Color.WHITE);
			title.setGravity(Gravity.CENTER_VERTICAL);
			title.setPadding(10,0,0,0);
		}
		
		addView(expand, Menu.dp(context, 20), Menu.dp(context, 20));
		addView(title, -1, -1);
		setLayoutParams(new LinearLayout.LayoutParams(-1, Menu.dp(context, 20)));
		
		setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				new DialogPicker(context, new DialogPicker.Callback() {
					public void onPick(int color) {
						setColor(color);
					}
				});
			}
		});
	}
}
