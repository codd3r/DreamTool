package Weave.menu;
import Weave.Utils;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import Weave.Main;

public class SecondPanel extends LinearLayout {
	Context context;
	
	public LinearLayout header, pages, bottom;
	public LinearLayout line;
	public ImageView icon;
	
	public TextView bottomTitle;
	public ScrollView scroll;
	public LinearLayout childscroll;
	
	public Menu menuinstance;
	
	public int mainColor = 0;
	public ArrayList<PageButton> pageList = new ArrayList<>();
	
	public PageButton newPage(String name, String path, String[] sects, int pd) {
		PageButton page = new PageButton(context, name, path, menuinstance.panelright, sects, pd);
		childscroll.addView(page);
		pageList.add(page);
		return page;
	}
	
	private float corner = 10;
	public SecondPanel(Context ctx, Menu mn) {
		super(ctx);
		context = ctx;
		menuinstance = mn;
		
		{ // panel
			setOrientation(LinearLayout.VERTICAL);
		}
		
		mainColor = ColorList.colorOrange();
		header = new LinearLayout(context);
		header.setOrientation(LinearLayout.VERTICAL);
		{ // Head
			GradientDrawable head = new GradientDrawable();
			head.setCornerRadii(new float[] {corner, corner, corner, corner, 0, 0, 0, 0});
			head.setColor(ColorList.colorMain());
			header.setBackgroundDrawable(head);
			
			icon = new ImageView(context);
			{
				Utils.SetAssets(context, icon, "icon.png");
				icon.setPadding(10,10,10,10);
				icon.setColorFilter(ColorList.colorOrange());
			}
			header.addView(icon, -1, -1);
		}
		
		line = new LinearLayout(context);
		{ // Line after header
			line.setBackgroundColor(ColorList.colorOrange());
		}
		
		pages = new LinearLayout(context);
		pages.setOrientation(LinearLayout.VERTICAL);
		{ // pages panel
			int colorTrans = Color.argb(240, Color.red(ColorList.colorMain()), Color.green(ColorList.colorMain()), Color.blue(ColorList.colorMain()));
			pages.setBackgroundColor(colorTrans);
		}
		
		bottom = new LinearLayout(context);
		bottom.setOrientation(LinearLayout.HORIZONTAL);
		{ // Bottom panel
			GradientDrawable bott = new GradientDrawable();
			bott.setCornerRadii(new float[] {0, 0, 0, 0, corner, corner, corner, corner});
			bott.setColor(ColorList.colorMain());
			bottom.setBackgroundDrawable(bott);
			
			bottomTitle = new TextView(context);
			{ // Bottom text
				bottomTitle = new TextView(context);
				bottomTitle.setText(Main.getTitleName());
				bottomTitle.setTextSize(10.5f);
				bottomTitle.setTypeface(Utils.font(context));
				bottomTitle.setTextColor(Color.WHITE);
				bottomTitle.setGravity(Gravity.CENTER);
				
				bottom.addView(bottomTitle, -1, -1);
			}
		}
		
		scroll = new ScrollView(context);
		childscroll = new LinearLayout(context);
		scroll.addView(childscroll, -1, -1);
		childscroll.setOrientation(LinearLayout.VERTICAL);
		
		addView(header, -1, Menu.dp(context, 25));
		addView(line, -1, Menu.dp(context, 2));
		
		pages.addView(scroll, -1, -1);
		addView(pages, new LinearLayout.LayoutParams(-1, -1, 1));
		
		addView(bottom, -1, Menu.dp(context, 25));
	}
}
