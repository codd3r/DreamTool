package Weave.menu;
import Weave.Utils;
import android.content.Context;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Color;

public class WeaveTitle extends LinearLayout {
	Context context;
	
	public TextView title;
	
	public WeaveTitle(Context ctx, String titletext) {
		super(ctx);
		context = ctx;
		
		title = new TextView(context);
		{ // Title textview
			title.setText(titletext);
			title.setTextSize(10.5f);
			title.setTypeface(Utils.font(context));
			title.setTextColor(Color.WHITE);
			title.setGravity(Gravity.CENTER);
			title.setPadding(10,0,10,0);
			
			GradientDrawable backg = new GradientDrawable();
			{ // Background text
				backg.setColor(ColorList.colorGrayLight());
				backg.setCornerRadius(5f);
				
				//title.setBackgroundDrawable(backg);
			}
		}
		
		addView(title, -1, -2);
		setGravity(Gravity.CENTER);
		setPadding(15,0,15,0);
		
		setLayoutParams(new LayoutParams(-1, Utils.dp(context, 13)));
	}
}
