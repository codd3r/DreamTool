package Weave.menu;

import Weave.Utils;
import android.content.Context;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

public class SectionButton extends LinearLayout {
	Context context;
	public LinearLayout expand;
	public TextView title;
	
	public SectionButton(Context ctx, String text) {
		super(ctx);
		context = ctx;
		
		expand = new LinearLayout(context);
		{ // Expand
			
		}
		
		title = new TextView(context);
		{ // Title sect
			title.setText(text);
			title.setTextSize(10.5f);
			title.setTypeface(Utils.font(context));
			title.setTextColor(ColorList.colorGrayLight());
			title.setGravity(Gravity.CENTER_VERTICAL);
		}
		
		addView(expand, Menu.dp(context, 25), -1);
		addView(title, -1, -1);
		
		setLayoutParams(new LinearLayout.LayoutParams(-1, Menu.dp(context, 25)));
	}
	
	public void setClick(OnClickListener clck) {
		setOnClickListener(clck);
		expand.setOnClickListener(clck);
		title.setOnClickListener(clck);
	}
}
