package Weave.menu;

import Weave.Utils;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

public class WeaveButton extends LinearLayout {
	Context context;
	
	public Button button;
	public Callback callback;
	
	public static interface Callback {
		public void onClick();
	}
	
	public void setCallback(Callback call) {
		callback = call;
	}
	
	public void click() {
		if (callback != null) callback.onClick();
		button.setTextColor(ColorList.colorGrayLight());
		button.setTextSize(10f);
		
		new Handler().postDelayed(new Runnable() {
			public void run() {
				button.setTextColor(Color.WHITE);
				button.setTextSize(9.5f);
			}
		}, 300);
	}
	
	public WeaveButton(Context ctx, String name) {
		super(ctx);
		context = ctx;
		
		button = new Button(context);
		{ // Button
			GradientDrawable butt = new GradientDrawable();
			butt.setColor(ColorList.colorHeader());
			butt.setCornerRadius(5f);
			
			button.setBackgroundDrawable(butt);
			
			button.setText(name);
			button.setTextColor(Color.WHITE);
			button.setTypeface(Utils.font(context));
			button.setTextSize(9.5f);
			button.setGravity(Gravity.CENTER);
			button.setPadding(0,0,0,0);
			
			{ // OnClick
				button.setOnClickListener(new OnClickListener() {
					public void onClick(View v) {
						click();
					}
				});
			}
		}
		
		setPadding(5,5,5,5);
		setLayoutParams(new LinearLayout.LayoutParams(-1, Menu.dp(context, 25)));
		
		addView(button, -1, -1);
	}
}
