package Weave.menu;


import Weave.Utils;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

class InputDialog extends Dialog {
	Context context;
	
	public LinearLayout line;
	public WeaveButton button;
	public EditText edittext;
	
	public static interface Callback {
		public void onPut(String text);
	}
	
	public InputDialog(Context ctx, String text, final Callback callback) {
		super(ctx);
		context = ctx;
		
		line = new LinearLayout(context);
		{ // Full layout
			line.setOrientation(LinearLayout.HORIZONTAL);
			line.setBackgroundColor(ColorList.colorMain());
			
			edittext = new EditText(context);
			{ // EditText layout
				edittext.setHint(text);
				edittext.setHintTextColor(ColorList.colorGrayLight());
				edittext.setTextColor(Color.WHITE);
				edittext.setBackgroundColor(ColorList.colorMain());
				edittext.setTextSize(13.5f);
				edittext.setPadding(15, 0, 0, 0);
				edittext.setTypeface(Utils.font(context));
			}
			
			button = new WeaveButton(context, "OK");
			{ // Ok button
				button.setCallback(new WeaveButton.Callback() {
					public void onClick() {
						callback.onPut(edittext.getText().toString());
						dismiss();
					}
				});
			}
		}
		
		line.setLayoutParams(new LinearLayout.LayoutParams(Menu.dp(context, 260), Menu.dp(context, 20)));
		line.addView(edittext, Menu.dp(context, 230), -1);
		line.addView(button, -1, -1);
		
		setContentView(line);
	}
}

public class WeaveInput extends LinearLayout {
	Context context;
	
	public LinearLayout background;
	public TextView title;
	
	public static interface Callback {
		public void onPut(String text);
	}
	public Callback callback;
	
	public void setCallback(Callback call) {
		callback = call;
	}
	
	public void setValue(String text) {
		if (text.length() > 15) {
			title.setText(text.substring(0, 15));
		} else {
			title.setText(text);
		}
		if (callback != null) callback.onPut(text);
	}
	
	public WeaveInput(Context ctx, final String text) {
		super(ctx);
		context = ctx;
		
		background = new LinearLayout(context);
	
		{ // Background input
			GradientDrawable back = new GradientDrawable();
			back.setColor(ColorList.colorMain());
			back.setStroke(3, ColorList.colorHeader());
			
			background.setBackgroundDrawable(back);
		}
		
		title = new TextView(context);
		{ // Text value
			title.setText("...");
			title.setTextSize(11.5f);
			title.setTypeface(Utils.font(context));
			title.setTextColor(Color.WHITE);
			title.setGravity(Gravity.CENTER_VERTICAL);
			title.setPadding(20,0,0,0);
			
			title.setOnClickListener(new OnClickListener() {
				public void onClick(View v) {
					InputDialog dlg = new InputDialog(context, text, new InputDialog.Callback() {
						public void onPut(String txt) {
							setValue(txt);
						}
					});
					dlg.show();
				}
			});
		}
		
		background.addView(title, -1, -1);
		addView(background, -1, -1);
		
		setLayoutParams(new LinearLayout.LayoutParams(-1, Menu.dp(context, 30)));
		setPadding(10, 10, 10, 10);
	}
}
