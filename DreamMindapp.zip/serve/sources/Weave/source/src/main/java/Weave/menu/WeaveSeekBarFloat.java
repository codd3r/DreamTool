package Weave.menu;

import Weave.Utils;
import android.content.Context;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.SeekBar.OnSeekBarChangeListener;

public class WeaveSeekBarFloat extends LinearLayout {
	Context context;
	
	public LinearLayout topLine, bottomLine;
	public TextView title, valueText;
	public Button increase, decrease;
	public SeekBar slider;
	
	public int max, current, value;
	public Callback callback;
	public int mainColor = 0;
	
	public static interface Callback {
		public void onChange(float value);
	}
	
	public void setCallback(Callback call) {
		callback = call;
	}
	
	public void setValue(int val) {
		if (val > max) val = max;
		if (val < 0) val = 0;
		float cv = (float)((float)val / 100.0f);
		value = val;
		valueText.setText(Float.toString(cv));
		slider.setProgress(value);
		if (callback != null) callback.onChange(cv);
	}
	
	public WeaveSeekBarFloat(Context ctx, String name, float max1, float current1) {
		super(ctx);
		context = ctx;
		
		{ // Other
			max = (int)(max1 * 100.0f);
			current = (int)(current1 * 100.0f);
			value = current;
		}
		
		mainColor = ColorList.colorOrange();
		setOrientation(LinearLayout.VERTICAL);
		
		topLine = new LinearLayout(context);
		{ // Top layout (Title, value);
			topLine.setOrientation(LinearLayout.HORIZONTAL);
			
			title = new TextView(context);
			{ // Title slider
				title.setText(name);
				title.setTextSize(10.5f);
				title.setTypeface(Utils.font(context));
				title.setTextColor(ColorList.colorGrayLight());
				title.setGravity(Gravity.CENTER_VERTICAL);
				title.setPadding(10,0,10,0);
			}
			
			valueText = new TextView(context);
			{ // Value text (right title)
				valueText.setText(Float.toString((float)current / 100.0f));
				valueText.setTextSize(10.5f);
				valueText.setTypeface(Utils.font(context));
				valueText.setTextColor(Color.WHITE);
				valueText.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
				valueText.setPadding(10,0,10,0);
			}
			
			topLine.addView(title, new LinearLayout.LayoutParams(-1, -1, 1));
			topLine.addView(valueText, -2, -1);
		}
		
		bottomLine = new LinearLayout(context);
		{ // Bottom line (Decrease, Slider, Increase)
			bottomLine.setOrientation(LinearLayout.HORIZONTAL);
			
			slider = new SeekBar(context);
			{ // Slider
				slider.setPadding(25,0,25,0);
				
				slider.setMax(max);
				slider.setProgress(current);
				GradientDrawable thumb = new GradientDrawable();
				thumb.setColor(mainColor);
				thumb.setSize(30, 30);
				thumb.setCornerRadius(100);
				//thumb.setPadding(40, 40, 40, 40);
				thumb.setStroke(6, Color.WHITE);
				thumb.setTintMode(PorterDuff.Mode.MULTIPLY);

				slider.setThumb(thumb);
				
				slider.getProgressDrawable().setColorFilter(mainColor, PorterDuff.Mode.MULTIPLY);
				
				{
					slider.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
						@Override
						public void onProgressChanged(SeekBar sl, int v, boolean b) {
							setValue(v);
						}
						
						@Override
						public void onStopTrackingTouch(SeekBar sl) {}
						@Override
						public void onStartTrackingTouch(SeekBar sl) {}
					});
				}
			}
			
			decrease = new Button(context);
			{ // Decrease (-) button
				decrease.setText("-");
				decrease.setPadding(0,0,0,0);
				decrease.setTextSize(10.5f);
				decrease.setTypeface(Utils.font(context));
				decrease.setTextColor(Color.WHITE);
				decrease.setGravity(Gravity.CENTER);
				
				GradientDrawable dec = new GradientDrawable();
				dec.setColor(ColorList.colorHeader());
				dec.setCornerRadius(5f);
				//dec.setPadding(10,10,10,10);
				
				decrease.setBackgroundDrawable(dec);
				
				decrease.setOnClickListener(new OnClickListener() {
					public void onClick(View v) {
						setValue(value-1);
					}
				});
			}
			
			increase = new Button(context);
			{ // Increase (+) button
				increase.setText("+");
				increase.setPadding(0,0,0,0);
				increase.setTextSize(10.5f);
				increase.setTypeface(Utils.font(context));
				increase.setTextColor(Color.WHITE);
				increase.setGravity(Gravity.CENTER);

				GradientDrawable dec = new GradientDrawable();
				dec.setColor(ColorList.colorHeader());
				dec.setCornerRadius(5f);
				//dec.setPadding(10,10,10,10);

				increase.setBackgroundDrawable(dec);
				
				increase.setOnClickListener(new OnClickListener() {
					public void onClick(View v) {
						setValue(value+1);
					}
				});
			}
			
			bottomLine.setPadding(5,5,5,0);
			
			bottomLine.addView(decrease, Menu.dp(context, 15), Menu.dp(context, 15));
			bottomLine.addView(slider, new LayoutParams(-1, -1, 1));
			bottomLine.addView(increase, Menu.dp(context, 15), Menu.dp(context, 15));
		}
		
		setLayoutParams(new LinearLayout.LayoutParams(-1, Menu.dp(context, 35)));
		addView(topLine, -1, Menu.dp(context, 15));
		addView(bottomLine, -1, Menu.dp(context, 20));
	}
}
