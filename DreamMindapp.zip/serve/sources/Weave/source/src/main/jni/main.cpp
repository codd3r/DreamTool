#include <pthread.h>
#include <jni.h>
#include <Includes/Utils.h>
#include <Includes/Logger.h>
#include <iostream>
#include <Substrate/SubstrateHook.h>
#include "KittyMemory/MemoryPatch.h"
#include "menu.h"

struct GiveWPN {
	int wpn = 0;
	int skin = 0;
	int slot = 1;
	bool give = false;
	bool select = false;
} give1;

struct BuyWPN {
	int id = 0;
	bool give = false;
	bool autobuy = false;
	int delay = 1;
	int exp = 0;
	bool rand = false;
	
	bool grenade = false;
	int grenadeid = 64;
} give2;

struct LegitSC {
	bool enabled = false;
	
	int ak47s[7] = {0, 1, 21, 126, 130, 169, 76};
	int ak47 = 0;
	int m4a4s[5] = {0, 17, 73, 199, 219};
	int m4a4 = 0;
	int an94s[3] = {0, 96, 165};
	int an94 = 0;
	int m4a1s[4] = {0, 23, 33, 121};
	int m4a1 = 0;
	int deagles[8] = {0, 55, 127, 35, 179, 198, 214, 20};
	int deagle = 0;
	int revolvers[6] = {0, 102, 103, 107, 151, 162};
	int revolver = 0;
	int awps[9] = {0, 32, 69, 70, 34, 200, 19, 218, 40};
	int awp = 0;
	int sscouts[5] = {0, 6, 64, 88, 163};
	int sscout = 0;
	int sv98s[4] = {0, 28, 36, 216};
	int sv98 = 0;
	int ssg08s[3] = {0, 148, 217};
	int ssg08 = 0;
	int karambits[5] = {0, 56, 95, 134, 222};
	int karambit = 0;
	int guts[3] = {0, 129, 168};
	int gut = 0;
	int butterflys[5] = {0, 77, 78, 79, 80};
	int butterfly = 0;
	int m9s[3] = {0, 114, 115};
	int m9 = 0;
	int flips[4] = {0, 152, 153, 154};
	int flip = 0;
	int bowies[3] = {0, 182, 221};
	int bowie = 0;
} skins;

struct buyNWpn {
	int wpns[9] = {1, 33, 32, 34, 2, 51, 54, 52, 53};
	int wpn = 0;
	bool buy = false;
	int knife = 3;
	bool buyk = false;
} buys;

struct pSpam {
	bool enable = false;
	int wpn = 0;
} polspam;

void giveKnife(int wp) {
	buys.knife = wp;
	buys.buyk = true;
}

void giveSkin(int id, int skin, int slot) {
	give1.wpn = id;
	give1.skin = skin;
	give1.slot = slot;
	give1.give = true;
}

void buyWeapon(int id) {
	give2.id = id;
	give2.give = true;
}

extern "C" {
const char *libName = "libil2cpp.so";

JNIEXPORT jstring  JNICALL Java_Weave_Main_getTitleName(JNIEnv *env, jobject activityObject) {
	return env->NewStringUTF("Alternative");
}

JNIEXPORT jobjectArray  JNICALL Java_Weave_Main_getFeatures(JNIEnv *env, jobject activityObject) {jobjectArray ret;
	const char *features[] = {
		"page_Skins_testicon.png_Visual,Visible,Inventory", // 0
		
		"block_0_0_Legit,Give", // 0, 1
		"block_0_1_Weapon list,Others", // 2, 3
		"block_0_2_Weapon,Skins", // 4, 5
		
		// Skins - Visual - Legit (0)
		
		"checkbox_0_Enabled_101",
		"title_0_AK47",
		"spinner_0_...,Confrontation,T.S.O.V,Nightpumpkin,Dungeon,Glacier,Ultrafrag_1",
		"title_0_M4A4",
		"spinner_0_...,Rage,Electronic,Biohazard,Portal_2",
		"title_0_AN94",
		"spinner_0_...,Lost,Holiday_3",
		"title_0_M4A1",
		"spinner_0_...,Digitaldogges,Shock,Redfox_4",
		"title_0_Deagle",
		"spinner_0_...,Neonbax,Hallowen,Digitalrain,Holiday,Underspace,Rose,Warrior_5",
		"title_0_R8 Revolver",
		"spinner_0_...,Fire,Oxid,Markov,Gold,Holiday_6",
		"title_0_AWP",
		"spinner_0_...,Digitalrain,Neonbax,Mramor,Void,Flora,Nightfrag,Oni,Deusvult_7",
		"title_0_Sscout",
		"spinner_0_...,Burningworms,Icicle,Holiday,Mechanist_8",
		"title_0_SV98",
		"spinner_0_...,Blazerthower,Nightjungle,Darkside_9",
		"title_0_SSG08",
		"spinner_0_...,Bloodhunt,Railgun_10",
		"title_0_Karambit",
		"spinner_0_...,Leaves,Snowball,Witch,Goldrush_11",
		"title_0_Gut knife",
		"spinner_0_...,Nightspider,Crystal_12",
		"title_0_Butterfly",
		"spinner_0_...,Acid,Neonkiller,Prototype,Technomage_13",
		"title_0_M9 Bayonet",
		"spinner_0_...,One,Sport_14",
		"title_0_Flip Knife",
		"spinner_0_...,Protector,Glow,Rainbow_15",
		"title_0_Bowie",
		"spinner_0_...,Zero,Destiny_16",
		
		// Skins - Visual - Give (1)
		"title_1_Give weapon",
		"input_1_Weapon id_10001",
		"input_1_Skin id_10002",
		"slider_1_Slot_3_1_10003",
		"button_1_Give_10004",
		"title_1_Polygon spam",
		"input_1_Weapon ID_10005",
		"checkbox_1_Enable_10006",
		
		// Skins - Visible - Weapon List (2)
		"title_2_Weapon choice",
		"spinner_2_AK47,M4A4,AN94,M4A1,DEAGLE,AWP,SSCOUT,SV98,SSG08_20001",
		"button_2_Buy weapon_20002",
		"title_2_Knifes list",
		"button_2_Karambit_20003",
		"button_2_Gut knife_20004",
		"button_2_Butterfly_20005",
		"button_2_M9 Bayonet_20006",
		"button_2_Flip Knife_20007",
		"button_2_Bowie_20008",
		"button_2_Ursus_20009",
		"button_2_Navaja_20010",
		"button_2_Hunting knife_20011",
		
		// Skins - Visible - Buy (3)
		"title_3_Buy weapon",
		"input_3_Weapon id_30001",
		"button_3_Send buy_30002",
		"slider_3_Spam delay_10_1_30003",
		"checkbox_3_Random knife_30005",
		"checkbox_3_Spam-buy_30004",
		"title_3_Grenades",
		"button_3_HE Grenade - 300$_30006",
		"button_3_Smoke Grenade - 300$_30007",
		"button_3_Flash Grenade - 200$_30008",
		
		// Skins - Inventory - Weapon (4)
		"title_4_Unlock",
		"checkbox_4_Unlock all weapons_40001",
		"checkbox_4_Unlock all attachments_40002",
		"title_4_Bundles",
		"checkbox_4_Unlock Prime_40003",
		"checkbox_4_Unlock Gut Pack_40004",
		"checkbox_4_Unlock Navaja Pack_40005",
		"checkbox_4_Unlock Hunting pack_40006",
		
		// Skins - Inventory - Skins (5)
		"title_5_Add inventory item",
		"input_5_Item ID_40007",
		"input_5_Skin ID_40008"
	};
	int Total_Feature = (sizeof features / sizeof features[0]);
	ret = (jobjectArray) env->NewObjectArray(Total_Feature, env->FindClass("java/lang/String"), env->NewStringUTF(""));int i;
	for (i = 0; i < Total_Feature; i++) env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));
	return (ret);
}

std::string jstring2string(JNIEnv *env, jstring jStr) {
    if (!jStr)
        return "";

    const jclass stringClass = env->GetObjectClass(jStr);
    const jmethodID getBytes = env->GetMethodID(stringClass, "getBytes", "(Ljava/lang/String;)[B");
    const jbyteArray stringJbytes = (jbyteArray) env->CallObjectMethod(jStr, getBytes, env->NewStringUTF("UTF-8"));

    size_t length = (size_t) env->GetArrayLength(stringJbytes);
    jbyte* pBytes = env->GetByteArrayElements(stringJbytes, NULL);

    std::string ret = std::string((char *)pBytes, length);
    env->ReleaseByteArrayElements(stringJbytes, pBytes, JNI_ABORT);

    env->DeleteLocalRef(stringJbytes);
    env->DeleteLocalRef(stringClass);
    return ret;
}

JNIEXPORT void JNICALL Java_Weave_Main_Callback(JNIEnv *env, jobject activityObject, jint feature, jboolean check, jint value, jfloat value2, jstring value3, jint red, jint green, jint blue) {
	std::string value_str = jstring2string(env, value3);
	switch (feature) {
		case 101:
			skins.enabled = check;
			break;
		case 1:
			skins.ak47 = skins.ak47s[value];
			break;
		case 2:
			skins.m4a4 = skins.m4a4s[value];
			break;
		case 3:
			skins.an94 = skins.an94s[value];
			break;
		case 4:
			skins.m4a1 = skins.m4a1s[value];
			break;
		case 5:
			skins.deagle = skins.deagles[value];
			break;
		case 6:
			skins.revolver = skins.revolvers[value];
			break;
		case 7:
			skins.awp = skins.awps[value];
			break;
		case 8:
			skins.sscout = skins.sscouts[value];
			break;
		case 9:
			skins.sv98 = skins.sv98s[value];
			break;
		case 10:
			skins.ssg08 = skins.ssg08s[value];
			break;
		case 11:
			skins.karambit = skins.karambits[value];
			break;
		case 12:
			skins.gut = skins.guts[value];
			break;
		case 13:
			skins.butterfly = skins.butterflys[value];
			break;
		case 14:
			skins.m9 = skins.m9s[value];
			break;
		case 15:
			skins.flip = skins.flips[value];
			break;
		case 16:
			skins.bowie = skins.bowies[value];
			break;
		
		case 10001:
			give1.wpn = atoi(value_str.c_str());
			break;
		case 10002:
			give1.skin = atoi(value_str.c_str());
			break;
		case 10003:
			give1.slot = value;
			break;
		case 10004:
			giveSkin(give1.wpn, give1.skin, give1.slot);
			break;
		case 10005:
			polspam.wpn = atoi(value_str.c_str());
			break;
		case 10006:
			polspam.enable = check;
			break;
		
		case 20001:
			buys.wpn = buys.wpns[value];
			break;
		case 20002:
			buys.buy = true;
			break;
		
		case 20003:
			giveKnife(3);
			break;
		case 20004:
			giveKnife(68);
			break;
		case 20005:
			giveKnife(69);
			break;
		case 20006:
			giveKnife(72);
			break;
		case 20007:
			giveKnife(76);
			break;
		case 20008:
			giveKnife(73);
			break;
		case 20009:
			giveKnife(86);
			break;
		case 20010:
			giveKnife(78);
			break;
		case 20011:
			giveKnife(77);
			break;
			
		case 30001:
			give2.id = atoi(value_str.c_str());
			break;
		case 30002:
			buyWeapon(give2.id);
			break;
		case 30003:
			give2.delay = value;
			break;
		case 30004:
			give2.autobuy = check;
			break;
		case 30005:
			give2.rand = check;
			break;
		case 30006:
			give2.grenade = true;
			give2.grenadeid = 64;
			break;
		case 30007:
			give2.grenade = true;
			give2.grenadeid = 65;
			break;
		case 30008:
			give2.grenade = true;
			give2.grenadeid = 66;
			break;
	}
		
}

// EX END

using namespace std;std::string utf16le_to_utf8(const std::u16string &u16str) {    if (u16str.empty()) { return std::string(); }    const char16_t *p = u16str.data();    std::u16string::size_type len = u16str.length();    if (p[0] == 0xFEFF) {        p += 1;        len -= 1;    }    std::string u8str;    u8str.reserve(len * 3);    char16_t u16char;    for (std::u16string::size_type i = 0; i < len; ++i) {        u16char = p[i];        if (u16char < 0x0080) {            u8str.push_back((char) (u16char & 0x00FF));            continue;        }        if (u16char >= 0x0080 && u16char <= 0x07FF) {            u8str.push_back((char) (((u16char >> 6) & 0x1F) | 0xC0));            u8str.push_back((char) ((u16char & 0x3F) | 0x80));            continue;        }        if (u16char >= 0xD800 && u16char <= 0xDBFF) {            uint32_t highSur = u16char;            uint32_t lowSur = p[++i];            uint32_t codePoint = highSur - 0xD800;            codePoint <<= 10;            codePoint |= lowSur - 0xDC00;            codePoint += 0x10000;            u8str.push_back((char) ((codePoint >> 18) | 0xF0));            u8str.push_back((char) (((codePoint >> 12) & 0x3F) | 0x80));            u8str.push_back((char) (((codePoint >> 06) & 0x3F) | 0x80));            u8str.push_back((char) ((codePoint & 0x3F) | 0x80));            continue;        }        {            u8str.push_back((char) (((u16char >> 12) & 0x0F) | 0xE0));            u8str.push_back((char) (((u16char >> 6) & 0x3F) | 0x80));            u8str.push_back((char) ((u16char & 0x3F) | 0x80));            continue;        }    }    return u8str;}typedef struct _monoString {    void *klass;    void *monitor;    int length;    const char *toChars(){        u16string ss((char16_t *) getChars(), 0, getLength());        string str = utf16le_to_utf8(ss);        return str.c_str();    }    char chars[0];    char *getChars() {        return chars;    }    int getLength() {        return length;    }    std::string get_string() {                return std::string(toChars());    }} monoString;monoString *CreateMonoString(const char *str) {    monoString *(*String_CreateString)(void *instance, const char *str) = (monoString *(*)(void *, const char *))getAbsoluteAddress("libil2cpp.so", 0xC5401C);     return String_CreateString(NULL, str);}


std::string to_string(int param)
{
    std::string str = "";
    for(str = ""; param ; param /= 10)
        str += (char)('0' + param % 10);
    reverse(str.begin(), str.end());
	if (str == "") str = "0";
    return str;
}

}

// ---------- Hooking ---------- //

template<typename T>
struct monoArray {
    void *klass;
    void *monitor;
    void *bounds;
    int capacity;
    T m_Items[0];

    int getCapacity() {
        return capacity;
    }

    T *getPointer() {
        return m_Items;
    }
    
    template<typename V = T>
    std::vector<V> toCPPlist() {
        std::vector<V> ret;
        for (int i = 0; i < capacity; i++)
            ret.push_back(m_Items[i]);
        return std::move(ret);
    }

    void copyFrom(std::vector<T> vec) {
        copyFrom(vec.data(), vec.size());
    }
    
    void copyFrom(T *arr, int size) {
        if (size > capacity)
            Resize(size);
        memcpy(arr, m_Items, capacity * sizeof(T));
    }

    void copyTo(T *arr) {
        memcpy(arr, m_Items, sizeof(T) * capacity);
    }
    
    T operator[] (int index) {
        return m_Items[index];
    }

    void Resize(int newSize) {
        if (newSize <= capacity) return;
        T* newArr = new T[newSize];
        memcpy(newArr, m_Items, capacity * sizeof(T));
        capacity = newSize;
    }
	
	monoArray<T>* MonoCreate(int size) {
		monoArray<T> *monoArr = (monoArray<T> *)malloc(sizeof(monoArray) + sizeof(T) * size);
        monoArr->capacity = size;
        return monoArr;
	}

    template<typename t>
    static monoArray<t> *Create(int size) {
        monoArray<t> *monoArr = (monoArray<t> *)malloc(sizeof(monoArray) + sizeof(t) * size);
        monoArr->capacity = size;
        return monoArr;
    }
    
    template<typename t>
    static monoArray<t> *Create(std::vector<t> vec) {
        return Create<t>(vec.data(), vec.size());
    }
    
    template<typename t>
    static monoArray<t> *Create(T *arr, int size) {
        monoArray<t> *monoArr = Create<t>(size);
        for (int i = 0; i < size; i++)
            monoArr->m_Items[i] = arr[i];
        return monoArr;
    }

};

void (*addWpn) (int slot, int itemid, int uid, int skinid, int mz, int fz, int mg, int sc, int si);
void (*selectSlot) (void* instance, int slt, bool bbbb, bool bbb2);
void *(*send_buy) (void* inst, monoArray<int*>* mass);
void *(*drow_wpn) ();

void (*old_updateClient) (...);
void updateClient (void *instance) {
	give2.exp++;
	if (give2.autobuy) {
		if (give2.exp > give2.delay) {
			give2.exp = 0;
			give2.give = true;
		}
	}
	
	int skin2 = give2.id;
	if (give2.rand) {
		int knifes[8] = {3, 68, 69, 72, 73, 76, 77, 78};
		skin2 = knifes[rand() % 8];
	}
	
	if (buys.buy) {
		buys.buy = false;
		monoArray<int*>* buyList;
		buyList = buyList->MonoCreate(7);
		for (int i = 0; i < 7; i++) {
			buyList->getPointer()[i] = (int*) 0;
		}
		buyList->getPointer()[2] = (int*) buys.wpn;
		send_buy(instance, buyList);
	}
	
	if (buys.buyk) {
		buys.buyk = false;
		monoArray<int*>* buyList;
		buyList = buyList->MonoCreate(7);
		for (int i = 0; i < 7; i++) {
			buyList->getPointer()[i] = (int*) 0;
		}
		buyList->getPointer()[2] = (int*) buys.knife;
		send_buy(instance, buyList);
	}
	
	if (give2.give) {
		give2.give = false;
		monoArray<int*>* buyList;
		buyList = buyList->MonoCreate(7);
		for (int i = 0; i < 7; i++) {
			buyList->getPointer()[i] = (int*) 0;
		}
		buyList->getPointer()[2] = (int*) skin2;
		send_buy(instance, buyList);
	}
	
	if (give2.grenade) {
		give2.grenade = false;
		monoArray<int*>* buyList;
		buyList = buyList->MonoCreate(7);
		for (int i = 0; i < 7; i++) {
			buyList->getPointer()[i] = (int*) 0;
		}
		buyList->getPointer()[3] = (int*) give2.grenadeid;
		send_buy(instance, buyList);
	}
	old_updateClient(instance);
}

void (*old_updateShooter) (...);
void updateShooter (void *instance) {
	if (instance != NULL) {
		if (give1.give) {
			give1.give = false;
			addWpn(give1.slot, give1.wpn, 777, give1.skin, 0, 0, 0, 0, 0);
			give1.select = true;
		}
		
		if (give1.select) {
			give1.select = false;
			selectSlot(instance, give1.slot, false, false);
		}
		
		if (polspam.enable) {
			addWpn(2, polspam.wpn, 777, 0, 0, 0, 0, 0, 0);
			selectSlot(instance, 2, false, false);
			drow_wpn();
		}
	}
	old_updateShooter(instance);
}

// LEGIT SKINCHANGER
void (*old_addWeapon) (...);
void addWeapon(int slot, int wpn, int uid, int skin, int m1, int m2, int m3, int m4, int m5) {
	if (skins.enabled) {
		switch (wpn) {
			case 1:
				skin = skins.ak47;
				break;
			case 33:
				skin = skins.m4a4;
				break;
			case 32:
				skin = skins.an94;
				break;
			case 34:
				skin = skins.m4a1;
				break;
			case 2:
				skin = skins.deagle;
				break;
			case 15:
				skin = skins.revolver;
				break;
			case 51:
				skin = skins.awp;
				break;
			case 54:
				skin = skins.sscout;
				break;
			case 52:
				skin = skins.sv98;
				break;
			case 53:
				skin = skins.ssg08;
				break;
			case 3:
				skin = skins.karambit;
				break;
			case 68:
				skin = skins.gut;
				break;
			case 69:
				skin = skins.butterfly;
				break;
			case 72:
				skin = skins.m9;
				break;
			case 76:
				skin = skins.flip;
				break;
			case 73:
				skin = skins.bowie;
				break;
			
		}
	}
	old_addWeapon(slot, wpn, uid, skin, m1, m2, m3, m4, m5);
}

void (*old_send77) (...);
void send77(void *instance, void *a, void *b) {
	//
}

#define ms(offset,newe,old) (MSHookFunction((void *) getAbsoluteAddress("libil2cpp.so", offset), (void *) newe,(void **) &old))
#define initf(x, y) if (y != 0) *(void **)(&x) = (void *)getAbsoluteAddress("libil2cpp.so", y)
#define initp(a,b,c,d) hexPatches.a = MemoryPatch::createWithHex(d,b,c)

void *hack_thread(void *) {
	
	ProcMap il2cppMap;
    do {
        il2cppMap = KittyMemory::getLibraryMap(libName);
        sleep(1);
    } while (!isLibraryLoaded(libName));
	
    // ---------- Hook ---------- //
	
	ms(0x3A0BE8, send77, old_send77);
	ms(0x39E798, updateClient, old_updateClient);
	ms(0x53D508, updateShooter, old_updateShooter);
	ms(0x6AE8FC, addWeapon, old_addWeapon);
	
	addWpn = (void (*)(int, int, int, int, int, int, int, int, int)) getAbsoluteAddress("libil2cpp.so", 0x6AE8FC);
	selectSlot = (void (*)(void*, int, bool, bool)) getAbsoluteAddress("libil2cpp.so", 0x544A20);
	send_buy = (void *(*)(void *, monoArray<int*>*)) getAbsoluteAddress("libil2cpp.so", 0x39F658);
	drow_wpn = (void *(*)()) getAbsoluteAddress("libil2cpp.so", 0x3C30D0);
	
    return NULL;
}

JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);

    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);

    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
JNI_OnUnload(JavaVM *vm, void *reserved) {}
