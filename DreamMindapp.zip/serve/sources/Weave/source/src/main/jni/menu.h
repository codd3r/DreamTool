std::string tab = "`";

std::string is(int param)
{
    std::string str = "";
    for(str = ""; param ; param /= 10)
        str += (char)('0' + param % 10);
    reverse(str.begin(), str.end());
	if (str == "") str = "0";
    return str;
}

const char* addPage(char* name, char* icon, char* sections) {
	std::string result = "page" + tab + std::string(name) + tab + std::string(icon) + tab + std::string(sections);
	return result.c_str();
}

const char* addBlock(int pageid, int sect, char* text) {
	std::string result = "block" + tab + is(pageid) + tab + is(sect) + tab + std::string(text);
	return result.c_str();
}

const char* addButton(int boxid, char* text, int feature) {
	std::string result = "button" + tab + is(boxid) + tab + std::string(text) + tab + is(feature);
	return result.c_str();
}

const char* addCheckBox(int boxid, char* text, int feature) {
	std::string result = "checkbox" + tab + is(boxid) + tab + std::string(text) + tab + is(feature);
	return result.c_str();
}

const char* addTitle(int boxid, char* text) {
	std::string result = "blocktitle" + tab + is(boxid) + tab + std::string(text);
	return result.c_str();
}
