from flask import Flask, request, jsonify, send_file, send_from_directory
import json, os, shutil, random
import requests
# BUILDER SOURCE

users = {}

read_db = lambda: json.load(open("users.json", "r"))
save_db = lambda: json.dump(users, open("users.json", "w"), indent=2, ensure_ascii=False)

read_source = lambda name: json.load(open(f"sources/{name}/setting.json", "r", encoding="UTF-8"))
save_source = lambda name, data: json.dump(data, open(f"sources/{name}/setting.json", "w", encoding="UTF-8"), indent=2, ensure_ascii=False)
readfile = lambda src: open(src, "r").read()
savefile = lambda src, text: exec(f'file = open("{src}", "w")\nfile.write("""{text}""")\nfile.close()')

users = read_db()
app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False

@app.route("/img/<src>", methods=["GET"])
def getimg(src):
	return send_file(f"sources/{src}/icon.png")

server_enable = True
server_info = "Foxodever: я путана, я гей, я кримедеве не знаю жаваскретп"
server_version = "1.2"
def check_server(func):
	def completefunc(*args, **kwargs):
		if server_enable:
			version = request.args.get("v")
			if version == server_version:
				return func(*args, **kwargs)
			else:
				return jsonify({"type": "error", "code": "Версия приложения устарела \n t.me/a123123c123456"})
		else:
			return jsonify({"type": "error", "code": server_info})
	
	completefunc.__name__ = func.__name__
	return completefunc

def prank_crack(function):
	def completefunc(*args, **kwargs):
		args = request.args
	
		login, password, hwid = args.get("login", "").lower(), args.get("password", "").lower(), args.get("hwid", "")
		if login not in users:
			if password != users[login]["password"]:
				if hwid != users[login]["hwid"]:
					return jsonify({"type": "success", "data": [
						{
							"src": "Crack",
							"data": {
								{
								  "name": "Крякер хуесос",
								  "author": "Маму твою шаманил",
								  "description": "Замечательный сурс, non alert, настройка в main.cpp, в сурсе имеются: Slider, SliderFloat, CheckBox, Title, Input, Spinner, Button, ColorPicker",
								  "likes": [
								    "mind"
								  ] * 9999,
								}
							},
							"islike": False
						}
					]})
		return function(*args, **kwargs)
		
	return completefunc

@app.route("/compile", methods=["POST"])
@check_server
def compilesource():
	
	args = request.args
	
	login, password, hwid = args.get("login", "").lower(), args.get("password", "").lower(), args.get("hwid", "")
	if login in users:
		if password == users[login]["password"]:
			if hwid == users[login]["hwid"]:
				data = json.loads(request.data.decode("UTF-8"))
				data["login"] = login
				
				build = readfile("build.jar")
				
				file = requests.post(build, data=json.dumps(data))
				a = open(f"builds/{login.lower()}.zip", "wb")
				a.write(file.content)
				a.close()
				return "true"
			else:
				print("Hwid no", hwid)
				return jsonify({"type": "error", "code": "Неверный HWID"})
		else:
			print("Password no", password)
			return jsonify({"type": "error", "code": "Неверный пароль"})
	else:
		print("Login no", login)
		return jsonify({"type": "error", "code": "Логин не найден"})

@app.route("/downmaker/<src>", methods=["GET"])
@check_server
def downmaker(src):
	args = request.args
	
	login, password, hwid = args.get("login", "").lower(), args.get("password", "").lower(), args.get("hwid", "")
	if login in users and src.lower() == login:
		if password == users[login]["password"]:
			if hwid == users[login]["hwid"]:
				return send_from_directory("builds/", f"{src.lower()}.zip", as_attachment=True)
			else:
				print("Hwid no", hwid)
				return jsonify({"type": "error", "code": "Неверный HWID"})
		else:
			print("Password no", password)
			return jsonify({"type": "error", "code": "Неверный пароль"})
	else:
		print("Login no", login)
		return jsonify({"type": "error", "code": "Логин не найден"})
	
@app.route("/icon/<src>", methods=["GET"])
@check_server
def getic(src):
	return send_file(f"icons/{src}.png")

@app.route("/register", methods=["GET"])
@check_server
def register():
	args = request.args
	login, password = args.get("login").lower(), args.get("password").lower()
	admincode = args.get("admin")
	if admincode == "prcenter":
		users[login] = {
			"avatar": "0",
			"password": password,
			"hwid": None,
			"ban": False
		}
		save_db()
		return "True"

def make_archive(source, destination):
	base = os.path.basename(destination)
	name = base.split('.')[0]
	format = base.split('.')[1]
	archive_from = os.path.dirname(source)
	archive_to = os.path.basename(source.strip(os.sep))
	shutil.make_archive(name, format, archive_from, archive_to)
	shutil.move('%s.%s'%(name,format), destination)

@app.route("/download", methods=["GET", "POST"])
@check_server
def download_source():
	args = request.args
	login, password, hwid, src = args.get("login", "").lower(), args.get("password", "").lower(), args.get("hwid", ""), args.get("src", None)
	if login in users:
		if password == users[login]["password"]:
			if hwid == users[login]["hwid"]:
				try: shutil.rmtree(f"sources/{src}/send/")
				except: pass
				
				shutil.copytree(f"sources/{src}/source/", f"sources/{src}/send/")
				#data = read_source(src)
#				data_file = open(f"sources/{src}/source/{data['antilicher'][0]}", "r").read()
#				file = open(f"sources/{src}/send/{data['antilicher'][0]}", "w")
#				file.write(data_file.replace("[AL]", login))
#				file.close()
#				
				#data_file2 = open(f"sources/{src}/source/{data['antilicher'][1]}", "r").read()
#				file2 = open(f"sources/{src}/send/{data['antilicher'][1]}", "w")
#			
#				color = "#%02x%02x%02x" % (random.randint(1, 255), random.randint(1, 255), random.randint(1, 255))
#				file2.write(data_file2.replace("[AL]", color))
#				file2.close()
				#currlog = readfile("logg.txt")
#				currlog += f"\n#{color.upper()} - {login}"
#				savefile("logg.txt", currlog.strip())
#						
				make_archive(f"sources/{src}/send", f"sources/{src}/send.zip")
				return send_from_directory(f"sources/{src}/", "send.zip", as_attachment=True)
			else:
				return jsonify({"type": "error", "code": "Неверный HWID"})
		else:
			return jsonify({"type": "error", "code": "Неверный пароль"})
	else:
		return jsonify({"type": "error", "code": "Логин не найден"})

def get_sources(login):
	files = os.listdir("sources/")
	files.remove("Crack")
	resp = []
	
	for file in files:
		data = read_source(file)
		del data["antilicher"]
		resp.append({
			"src": file,
			"data": data,
			"islike": login in data["likes"]
		})
	
	return resp

@app.route("/like", methods=["GET"])
@check_server
def setliked():
	args = request.args
	login, password, hwid, src = args.get("login").lower(), args.get("password").lower(), args.get("hwid"), args.get("src")
	if login in users:
		if password == users[login]["password"]:
			if hwid == users[login]["hwid"]:
				source = read_source(src)
				if login in source["likes"]:
					del source["likes"][source["likes"].index(login)]
				else:
					source["likes"].append(login)
				save_source(src, source)
				return jsonify({"type": "success", "data": {
					"count": len(source["likes"]),
					"islike": login in source["likes"]
				}})
				
			else:
				return jsonify({"type": "error", "code": "Неверный HWID"})
		else:
			return jsonify({"type": "error", "code": "Неверный пароль"})
	else:
		return jsonify({"type": "error", "code": "Логин не найден"})

@app.route("/source_info", methods=["GET"])
@check_server
def sourceinfo():
	args = request.args
	login, password, hwid, src = args.get("login").lower(), args.get("password").lower(), args.get("hwid"), args.get("src")
	
	if login in users:
		if password == users[login]["password"]:
			if hwid == users[login]["hwid"]:
				source = read_source(src)
				return jsonify({"type": "success", "data": {
					"name": source["name"],
					"author": source["author"],
					"description": source["description"],
					"likes": len(source["likes"])
				}})
				
			else:
				return jsonify({"type": "error", "code": "Неверный HWID"})
		else:
			return jsonify({"type": "error", "code": "Неверный пароль"})
	else:
		return jsonify({"type": "error", "code": "Логин не найден"})

@app.route("/change_pass", methods=["GET"])
@check_server
def changepass():
	args = request.args
	login, password, hwid, newpass = args.get("login").lower(), args.get("password").lower(), args.get("hwid"), args.get("newpass")
	
	if login in users:
		if password == users[login]["password"]:
			if hwid == users[login]["hwid"]:
				users[login]["password"] = newpass.lower()
				save_db()
				return jsonify({"type": "success", "code": "Пароль изменен"})
			else:
				return jsonify({"type": "error", "code": "Неверный HWID"})
		else:
			return jsonify({"type": "error", "code": "Неверный пароль"})
	else:
		return jsonify({"type": "error", "code": "Логин не найден"})

@app.route("/get_sources", methods=["GET"])
@check_server
def sourcelist():
	args = request.args
	login, password, hwid = args.get("login").lower(), args.get("password").lower(), args.get("hwid")		
	a1,a2,a3 = False, False, False
	if login in users:
		if password == users[login]["password"]:
			if hwid == users[login]["hwid"]:
				
				return jsonify({"type": "success", "data": get_sources(login)})
				
			else:
				a1 = True #return jsonify({"type": "error", "code": "Неверный HWID"})
		else:
			a2 = True #return jsonify({"type": "error", "code": "Неверный пароль"})
	else:
		a3 = True #return jsonify({"type": "error", "code": "Логин не найден"})
	
	if a1 or a2 or a3:
		return jsonify({"type": "success", "data": [
					{
							"src": "Crack",
							"data": {
								  "name": "Крякер хуесос",
								  "author": "Маму твою шаманил",
								  "description": "Замечательный сурс, non alert, настройка в main.cpp, в сурсе имеются: Slider, SliderFloat, CheckBox, Title, Input, Spinner, Button, ColorPicker",
								  "likes": [
								    "mind"
								  ] * 9999,
							},
							"islike": False
						}
					]})
@app.route("/auth", methods=["GET"])
@check_server
def auth():
	args = request.args
		
	if args.get("login").lower() in users:
		if args.get("password").lower() == users[args.get("login").lower()]["password"].lower():
			
			if users[args.get("login").lower()]["hwid"] == None:
				users[args.get("login").lower()]["hwid"] = args.get("hwid")
				save_db()
			if args.get("hwid") == users[args.get("login").lower()]["hwid"]:
				
				return jsonify({
					"type": "success",
					"code": {
						"avatar": users[args.get("login").lower()]["avatar"],
						"nick": args.get("login").lower(),
						"ban": users[args.get("login").lower()]["ban"]
					}
				})
				
			else:
				return jsonify({"type": "error", "code": "Неверный HWID"})
		else:
			return jsonify({"type": "error", "code": "Неверный пароль"})
	else:
		return jsonify({"type": "error", "code": "Логин не найден"})

if __name__ == "__main__":
	app.run()
