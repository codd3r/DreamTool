package com.minddev.mindapp;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ScrollView;
import java.util.ArrayList;
import android.widget.TextView;
import java.io.Serializable;
import android.widget.ImageView;
import android.graphics.Typeface;

class AlertSettingLinearLayout extends Dialog {
	Context context;
	
	public EditorLinearLayout linear;
	public ScrollView scroll;
	public LinearLayout main;

	public AlertSettingLinearLayout(final Context context, final EditorLinearLayout linear) {
		super(context);
		this.context = context;
		this.linear = linear;

		scroll = new ScrollView(context);
		scroll.setFillViewport(true);

		main = new LinearLayout(context);
		main.setOrientation(LinearLayout.VERTICAL);
		scroll.addView(main, Utils.dp(context, 300), -1);

		setContentView(scroll);

		toParent = new AlertButton(context, "To parent", "");
		toParent.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					dismiss();
					linear.parent.edit();
				}
			});
			
		removeView = new AlertButton(context, "Remove this view", "");
		removeView.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					dismiss();
					linear.parent.childs.remove(linear);
					linear.parent.update();
				}
			});

		addInside = new AlertButton(context, "Add inside", "");
		addInside.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v){
					dismiss();
					AlertPicker picker = new AlertPicker(context, new String[][] {
						{"LinearLayout: ", "Vertical"},
						{"LinearLayout: ", "Horizontal"},
						{"TextView: ", "default"},
						{"ImageView: ", "from assets"}
					});
					picker.callback = new AlertPicker.Callback() {
						public void pick(int id) {
							if (id == 0) {
								linear.addLinear().orientation = LinearLayout.VERTICAL;
							}

							if (id == 1) {
								linear.addLinear().orientation = LinearLayout.HORIZONTAL;
							}
							
							if (id == 2) {
								linear.addTextView();
							}
							
							if (id == 3) {
								linear.addImage();
							}

							linear.update();
						}
					};
				}
			});
		
		color = new AlertButton(context, "Background color = ", Utils.getHex(linear.color));
		color.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v){
					final AlertColor colorp = new AlertColor(context);
					colorp.inp.button.setOnClickListener(new View.OnClickListener() {
							public void onClick(View v) {
								colorp.dismiss();
								int c = Color.parseColor(colorp.inp.edittext.getText().toString().trim());
								color.text.setText(Utils.getHex(c));
								linear.color = c;
								linear.update();
							}
						});
					colorp.show();
				}
			});

		corner = new AlertButton(context, "Corner = ", Float.toString(linear.corner[0]));
		corner.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Float.toString(0), "Corner");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								float value = Float.parseFloat(output);
								value = value < 0 ? 0 : value;
								linear.corner[0] = value;
								linear.corner[1] = value;
								linear.corner[2] = value;
								linear.corner[3] = value;

								corner1.text.setText(Float.toString(value));
								corner2.text.setText(Float.toString(value));
								corner3.text.setText(Float.toString(value));
								corner4.text.setText(Float.toString(value));

								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		corner1 = new AlertButton(context, "Corner left-top = ", Float.toString(linear.corner[0]));
		corner1.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Float.toString(linear.corner[0]), "Corner left-top");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								float value = Float.parseFloat(output);
								value = value < 0 ? 0 : value;
								linear.corner[0] = value;
								corner1.text.setText(Float.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		corner2 = new AlertButton(context, "Corner right-top = ", Float.toString(linear.corner[1]));
		corner2.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Float.toString(linear.corner[1]), "Corner right-top");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								float value = Float.parseFloat(output);
								value = value < 0 ? 0 : value;
								linear.corner[1] = value;
								corner2.text.setText(Float.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		corner3 = new AlertButton(context, "Corner right-bottom = ", Float.toString(linear.corner[2]));
		corner3.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Float.toString(linear.corner[2]), "Corner right-bottom");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								float value = Float.parseFloat(output);
								value = value < 0 ? 0 : value;
								linear.corner[2] = value;
								corner3.text.setText(Float.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		corner4 = new AlertButton(context, "Corner left-bottom = ", Float.toString(linear.corner[3]));
		corner4.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Float.toString(linear.corner[3]), "Corner left-bottom");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								float value = Float.parseFloat(output);
								value = value < 0 ? 0 : value;
								linear.corner[3] = value;
								corner4.text.setText(Float.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		padding = new AlertButton(context, "Padding = ", Integer.toString(linear.padding[0]));
		padding.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, "0", "Padding");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.padding[0] = value;
								linear.padding[1] = value;
								linear.padding[2] = value;
								linear.padding[3] = value;

								padding1.text.setText(Integer.toString(value));
								padding2.text.setText(Integer.toString(value));
								padding3.text.setText(Integer.toString(value));
								padding4.text.setText(Integer.toString(value));

								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		padding1 = new AlertButton(context, "Padding left = ", Integer.toString(linear.padding[0]));
		padding1.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.padding[0]), "Padding left");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.padding[0] = value;
								padding1.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		padding2 = new AlertButton(context, "Padding top = ", Integer.toString(linear.padding[1]));
		padding2.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.padding[1]), "Padding top");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.padding[1] = value;
								padding2.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		padding3 = new AlertButton(context, "Padding right = ", Integer.toString(linear.padding[2]));
		padding3.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.padding[2]), "Padding right");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.padding[2] = value;
								padding3.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		padding4 = new AlertButton(context, "Padding bottom = ", Integer.toString(linear.padding[3]));
		padding4.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.padding[3]), "Padding bottom");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.padding[3] = value;
								padding4.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		margin = new AlertButton(context, "Margin = ", Integer.toString(linear.margin[0]));
		margin.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, "0", "Margin");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.margin[0] = value;
								linear.margin[1] = value;
								linear.margin[2] = value;
								linear.margin[3] = value;

								margin1.text.setText(Integer.toString(value));
								margin2.text.setText(Integer.toString(value));
								margin3.text.setText(Integer.toString(value));
								margin4.text.setText(Integer.toString(value));

								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		margin1 = new AlertButton(context, "Margin left = ", Integer.toString(linear.margin[0]));
		margin1.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.margin[0]), "Margin left");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.margin[0] = value;
								margin1.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		margin2 = new AlertButton(context, "Margin top = ", Integer.toString(linear.margin[1]));
		margin2.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.margin[1]), "Margin top");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.margin[1] = value;
								margin2.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});
	
			
		setid = new AlertButton(context, "ID = ", linear.id);
		setid.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v){
					final AlertInput textset = new AlertInput(context, "", "ID");
					textset.callback = new AlertInput.Callback() {
						public void onPut(String txt) {
							linear.id = txt;
							linear.update();
							setid.text.setText(txt);
						}
					};
				}
			});

		margin3 = new AlertButton(context, "Margin right = ", Integer.toString(linear.margin[2]));
		margin3.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.margin[2]), "Margin right");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.margin[2] = value;
								margin3.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		margin4 = new AlertButton(context, "Margin bottom = ", Integer.toString(linear.margin[3]));
		margin4.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.margin[3]), "Margin bottom");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.margin[3] = value;
								margin4.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});
			
		strokeWidth = new AlertButton(context, "Stroke width = ", Integer.toString(linear.stroke_width));
		strokeWidth.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.stroke_width), "Stroke width");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.stroke_width = value;
								strokeWidth.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});
		
			

		strokeColor = new AlertButton(context, "Stroke color = ", Utils.getHex(linear.stroke_color));
		strokeColor.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v){
					final AlertColor colorp = new AlertColor(context);
					colorp.inp.button.setOnClickListener(new View.OnClickListener() {
							public void onClick(View v) {
								colorp.dismiss();
								int c = Color.parseColor(colorp.inp.edittext.getText().toString().trim());
								strokeColor.text.setText(Utils.getHex(c));
								linear.stroke_color = c;
								linear.update();
							}
						});
					colorp.show();
				}
			});

		layoutWidth = new AlertButton(context, "Layout width = ", Utils.getDp(context, linear.width));
		layoutWidth.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					String inputhint = linear.width < 0 ? Integer.toString(linear.width) : Integer.toString(Utils.pd(context, linear.width));
					AlertInput input = new AlertInput(context, inputhint, "Layout width");
					input.callback = new AlertInput.Callback() {
						public void onPut(String value) {
							try {
								if (Integer.parseInt(value) != -1 && Integer.parseInt(value) != -2) {
									linear.width = Utils.dp(context, Integer.parseInt(value));
								} else {
									linear.width = Integer.parseInt(value);
								}
								layoutWidth.text.setText(Utils.getDp(context, linear.width));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		layoutHeight = new AlertButton(context, "Layout height = ", Utils.getDp(context, linear.height));
		layoutHeight.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					String inputhint = linear.height < 0 ? Integer.toString(linear.height) : Integer.toString(Utils.pd(context, linear.height));
					AlertInput input = new AlertInput(context, inputhint, "Layout height");
					input.callback = new AlertInput.Callback() {
						public void onPut(String value) {
							try {
								if (Integer.parseInt(value) != -1 && Integer.parseInt(value) != -2) {
									linear.height = Utils.dp(context, Integer.parseInt(value));
								} else {
									linear.height = Integer.parseInt(value);
								}
								layoutHeight.text.setText(Utils.getDp(context, linear.height));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		layoutWeight = new AlertButton(context, "Layout weight = ", Integer.toString(linear.weight));
		layoutWeight.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.weight), "Layout weight");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.weight = value;
								layoutWeight.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});
		orientation = new AlertButton(context, "Orientation = ", linear.orientation == 0 ? "HORIZONTAL" : "VERTICAL");
		orientation.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					linear.orientation = linear.orientation == 0 ? 1 : 0;
					orientation.text.setText(linear.orientation == 0 ? "HORIZONTAL" : "VERTICAL");
					linear.update();
				}
			});

		gravity = new AlertButton(context, "Gravity = ", "...");
		gravity.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertGravityPicker pick = new AlertGravityPicker(context, linear);
				}
			});
	}

	public AlertButton toParent, removeView;
	public AlertButton addInside;
	public AlertButton color, corner, corner1, corner2, corner3, corner4, strokeWidth, strokeColor;
	public AlertButton layoutWidth, layoutHeight, layoutWeight, orientation, gravity;
	public AlertButton padding, padding1, padding2, padding3, padding4;
	public AlertButton margin, margin1, margin2, margin3, margin4;
	public AlertButton setid;
	
	public void showMenu() {
		main.removeAllViews();

		if (linear.parent != null) {
			main.addView(toParent);
			main.addView(addInside);
			main.addView(removeView);
		}
		
		main.addView(setid);

		main.addView(color);
		
		main.addView(corner);
		main.addView(corner1);
		main.addView(corner2);
		main.addView(corner3);
		main.addView(corner4);

		main.addView(strokeWidth);
		main.addView(strokeColor);

		main.addView(layoutWidth);
		main.addView(layoutHeight);
		main.addView(layoutWeight);
		main.addView(orientation);
		main.addView(gravity);

		main.addView(padding);
		main.addView(padding1);
		main.addView(padding2);
		main.addView(padding3);
		main.addView(padding4);

		main.addView(margin);
		main.addView(margin1);
		main.addView(margin2);
		main.addView(margin3);
		main.addView(margin4);
		
		create();
		show();
	}
}

class EditorLinearLayout extends LinearLayout {
	Context context;
	public ArrayList<View> childs = new ArrayList<>();

	public EditorLinearLayout parent = null;

	public int orientation = 0;
	public int width = -2;
	public int height = -2;
	public int weight = 0;

	public int gravity = 0;

	public int color = Color.TRANSPARENT;
	public float[] corner = new float[] {0, 0, 0, 0};

	public int stroke_width = 1;
	public int stroke_color = 0;
	
	public String id = null;

	public int[] padding = {0, 0, 0, 0};
	public int[] margin = {0, 0, 0, 0};

	public int getIndex() {
		if (parent == null) return -1;
		return parent.childs.indexOf(this);
	}

	public EditorLinearLayout(Context context) {
		super(context);
		this.context = context;

		orientation = LinearLayout.VERTICAL;

		setMinimumHeight(Utils.dp(context, 25));
		setMinimumWidth(Utils.dp(context, 25));

		gravity = Gravity.TOP | Gravity.LEFT;
		padding = new int[]{5,5,5,5};

		//color = Color.rgb((int)(Math.random()*255), (int)(Math.random()*255), (int)(Math.random()*255));
		stroke_color = Color.BLACK;
	}

	public void edit() {
		AlertSettingLinearLayout al = new AlertSettingLinearLayout((Context) this.context, this);
		al.showMenu();
	}

	public EditorLinearLayout addLinear() {
		final EditorLinearLayout layout = new EditorLinearLayout(this.context);

		layout.height = -2;
		layout.width = -2;
		layout.parent = this;
		
		SourceCreatorActivity.objId++;
		layout.id = "linear" + Integer.toString(SourceCreatorActivity.objId);

		childs.add(layout);
		update();

		layout.setOnClickListener(new OnClickListener() {
				public void onClick(View v) {
					layout.edit();
				}
			});

		return layout;
	}
	
	public EditorImageView addImage() {
		final EditorImageView layout = new EditorImageView(this.context);

		layout.height = -2;
		layout.width = -2;
		layout.parent = this;

		SourceCreatorActivity.objId++;
		layout.id = "imageview" + Integer.toString(SourceCreatorActivity.objId);

		childs.add(layout);
		update();

		layout.setOnClickListener(new OnClickListener() {
				public void onClick(View v) {
					layout.edit();
				}
			});

		return layout;
	}
	
	public EditorTextView addTextView() {
		final EditorTextView layout = new EditorTextView(this.context);

		layout.height = -2;
		layout.width = -2;
		layout.parent = this;
		SourceCreatorActivity.objId++;
		layout.id = "textview" + Integer.toString(SourceCreatorActivity.objId);

		childs.add(layout);
		update();

		layout.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				layout.edit();
			}
		});

		return layout;
	}

	public void update() {

		setMinimumHeight(Utils.dp(context, 25));
		setMinimumWidth(Utils.dp(context, 25));
		
		setOrientation(orientation);
		setPadding(padding[0], padding[1], padding[2], padding[3]);
		setGravity(gravity);

		GradientDrawable design = new GradientDrawable();
		design.setColor(color);
		design.setCornerRadii(new float[] {corner[0], corner[0], corner[1], corner[1], corner[2], corner[2], corner[3], corner[3]});
		design.setStroke(stroke_width, stroke_color);
		setBackgroundDrawable(design);

		LayoutParams lp = new LayoutParams(width, height, weight);
		lp.leftMargin   = margin[0];
		lp.topMargin    = margin[1];
		lp.rightMargin  = margin[2];
		lp.bottomMargin = margin[3];
		setLayoutParams(lp);

		removeAllViews();

		for (View view: childs) {
			addView(view);

			if (view instanceof EditorLinearLayout) {
				((EditorLinearLayout) view).update();
			} else if (view instanceof EditorTextView) {
				((EditorTextView) view).update();
			} else if (view instanceof EditorImageView) {
				((EditorImageView) view).update();
			}
		}
	}
}

class AlertSettingTextView extends Dialog {
	Context context;
	public EditorTextView linear;
	public ScrollView scroll;
	public LinearLayout main;

	public AlertSettingTextView(final Context context, final EditorTextView linear) {
		super(context);
		this.context = context;
		this.linear = linear;

		scroll = new ScrollView(context);
		scroll.setFillViewport(true);

		main = new LinearLayout(context);
		main.setOrientation(LinearLayout.VERTICAL);
		scroll.addView(main, Utils.dp(context, 300), -1);

		setContentView(scroll);

		toParent = new AlertButton(context, "To parent", "");
		toParent.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					dismiss();
					linear.parent.edit();
				}
			});

		removeView = new AlertButton(context, "Remove this view", "");
		removeView.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					dismiss();
					linear.parent.childs.remove(linear);
					linear.parent.update();
				}
			});
			
		
		setid = new AlertButton(context, "ID = ", linear.id);
		setid.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v){
					final AlertInput textset = new AlertInput(context, "", "ID");
					textset.callback = new AlertInput.Callback() {
						public void onPut(String txt) {
							linear.id = txt;
							linear.update();
							setid.text.setText(txt);
						}
					};
				}
			});
			
		settext = new AlertButton(context, "Text = ", linear.text);
		settext.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v){
				final AlertInput textset = new AlertInput(context, "", "Text");
				textset.callback = new AlertInput.Callback() {
					public void onPut(String txt) {
						linear.text = txt;
						linear.update();
						settext.text.setText(txt);
					}
				};
			}
		});
		
		textcolor = new AlertButton(context, "Text color = ", Utils.getHex(linear.text_color));
		textcolor.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v){
				final AlertColor colorp = new AlertColor(context);
				colorp.inp.button.setOnClickListener(new View.OnClickListener() {
						public void onClick(View v) {
							colorp.dismiss();
							int c = Color.parseColor(colorp.inp.edittext.getText().toString().trim());
							textcolor.text.setText(Utils.getHex(c));
							linear.text_color = c;
							linear.update();
						}
					});
				colorp.show();
			}
		});
		
		textsize = new AlertButton(context, "Text size = ", Float.toString(linear.text_size));
		textsize.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				AlertInput inp = new AlertInput(context, Float.toString(linear.text_size), "Text size");
				inp.callback = new AlertInput.Callback() {
					public void onPut(String output) {
						try {
							float value = Float.parseFloat(output);
							value = value < 0 ? 0 : value;
							linear.text_size = value;
							textsize.text.setText(Float.toString(value));
							linear.update();
						} catch (Exception e) {}
					}
				};
			}
		});
		
		color = new AlertButton(context, "Background color = ", Utils.getHex(linear.color));
		color.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v){
					final AlertColor colorp = new AlertColor(context);
					colorp.inp.button.setOnClickListener(new View.OnClickListener() {
							public void onClick(View v) {
								colorp.dismiss();
								int c = Color.parseColor(colorp.inp.edittext.getText().toString().trim());
								color.text.setText(Utils.getHex(c));
								linear.color = c;
								linear.update();
							}
						});
					colorp.show();
				}
			});

		corner = new AlertButton(context, "Corner = ", Float.toString(linear.corner[0]));
		corner.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Float.toString(0), "Corner");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								float value = Float.parseFloat(output);
								value = value < 0 ? 0 : value;
								linear.corner[0] = value;
								linear.corner[1] = value;
								linear.corner[2] = value;
								linear.corner[3] = value;

								corner1.text.setText(Float.toString(value));
								corner2.text.setText(Float.toString(value));
								corner3.text.setText(Float.toString(value));
								corner4.text.setText(Float.toString(value));

								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		corner1 = new AlertButton(context, "Corner left-top = ", Float.toString(linear.corner[0]));
		corner1.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Float.toString(linear.corner[0]), "Corner left-top");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								float value = Float.parseFloat(output);
								value = value < 0 ? 0 : value;
								linear.corner[0] = value;
								corner1.text.setText(Float.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		corner2 = new AlertButton(context, "Corner right-top = ", Float.toString(linear.corner[1]));
		corner2.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Float.toString(linear.corner[1]), "Corner right-top");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								float value = Float.parseFloat(output);
								value = value < 0 ? 0 : value;
								linear.corner[1] = value;
								corner2.text.setText(Float.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		corner3 = new AlertButton(context, "Corner right-bottom = ", Float.toString(linear.corner[2]));
		corner3.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Float.toString(linear.corner[2]), "Corner right-bottom");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								float value = Float.parseFloat(output);
								value = value < 0 ? 0 : value;
								linear.corner[2] = value;
								corner3.text.setText(Float.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		corner4 = new AlertButton(context, "Corner left-bottom = ", Float.toString(linear.corner[3]));
		corner4.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Float.toString(linear.corner[3]), "Corner left-bottom");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								float value = Float.parseFloat(output);
								value = value < 0 ? 0 : value;
								linear.corner[3] = value;
								corner4.text.setText(Float.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		padding = new AlertButton(context, "Padding = ", Integer.toString(linear.padding[0]));
		padding.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, "0", "Padding");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.padding[0] = value;
								linear.padding[1] = value;
								linear.padding[2] = value;
								linear.padding[3] = value;

								padding1.text.setText(Integer.toString(value));
								padding2.text.setText(Integer.toString(value));
								padding3.text.setText(Integer.toString(value));
								padding4.text.setText(Integer.toString(value));

								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		padding1 = new AlertButton(context, "Padding left = ", Integer.toString(linear.padding[0]));
		padding1.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.padding[0]), "Padding left");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.padding[0] = value;
								padding1.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		padding2 = new AlertButton(context, "Padding top = ", Integer.toString(linear.padding[1]));
		padding2.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.padding[1]), "Padding top");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.padding[1] = value;
								padding2.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		padding3 = new AlertButton(context, "Padding right = ", Integer.toString(linear.padding[2]));
		padding3.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.padding[2]), "Padding right");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.padding[2] = value;
								padding3.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		padding4 = new AlertButton(context, "Padding bottom = ", Integer.toString(linear.padding[3]));
		padding4.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.padding[3]), "Padding bottom");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.padding[3] = value;
								padding4.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});
			
		margin = new AlertButton(context, "Margin = ", Integer.toString(linear.margin[0]));
		margin.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, "0", "Margin");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.margin[0] = value;
								linear.margin[1] = value;
								linear.margin[2] = value;
								linear.margin[3] = value;

								margin1.text.setText(Integer.toString(value));
								margin2.text.setText(Integer.toString(value));
								margin3.text.setText(Integer.toString(value));
								margin4.text.setText(Integer.toString(value));

								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		margin1 = new AlertButton(context, "Margin left = ", Integer.toString(linear.margin[0]));
		margin1.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.margin[0]), "Margin left");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.margin[0] = value;
								margin1.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		margin2 = new AlertButton(context, "Margin top = ", Integer.toString(linear.margin[1]));
		margin2.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.margin[1]), "Margin top");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.margin[1] = value;
								margin2.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		margin3 = new AlertButton(context, "Margin right = ", Integer.toString(linear.margin[2]));
		margin3.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.margin[2]), "Margin right");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.margin[2] = value;
								margin3.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		margin4 = new AlertButton(context, "Margin bottom = ", Integer.toString(linear.margin[3]));
		margin4.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.margin[3]), "Margin bottom");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.margin[3] = value;
								margin4.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});
		

		strokeWidth = new AlertButton(context, "Stroke width = ", Integer.toString(linear.stroke_width));
		strokeWidth.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.stroke_width), "Stroke width");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.stroke_width = value;
								strokeWidth.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		strokeColor = new AlertButton(context, "Stroke color = ", Utils.getHex(linear.stroke_color));
		strokeColor.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v){
					final AlertColor colorp = new AlertColor(context);
					colorp.inp.button.setOnClickListener(new View.OnClickListener() {
							public void onClick(View v) {
								colorp.dismiss();
								int c = Color.parseColor(colorp.inp.edittext.getText().toString().trim());
								strokeColor.text.setText(Utils.getHex(c));
								linear.stroke_color = c;
								linear.update();
							}
						});
					colorp.show();
				}
			});

		layoutWidth = new AlertButton(context, "Layout width = ", Utils.getDp(context, linear.width));
		layoutWidth.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					String inputhint = linear.width < 0 ? Integer.toString(linear.width) : Integer.toString(Utils.pd(context, linear.width));
					AlertInput input = new AlertInput(context, inputhint, "Layout width");
					input.callback = new AlertInput.Callback() {
						public void onPut(String value) {
							try {
								if (Integer.parseInt(value) != -1 && Integer.parseInt(value) != -2) {
									linear.width = Utils.dp(context, Integer.parseInt(value));
								} else {
									linear.width = Integer.parseInt(value);
								}
								layoutWidth.text.setText(Utils.getDp(context, linear.width));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		layoutHeight = new AlertButton(context, "Layout height = ", Utils.getDp(context, linear.height));
		layoutHeight.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					String inputhint = linear.height < 0 ? Integer.toString(linear.height) : Integer.toString(Utils.pd(context, linear.height));
					AlertInput input = new AlertInput(context, inputhint, "Layout height");
					input.callback = new AlertInput.Callback() {
						public void onPut(String value) {
							try {
								if (Integer.parseInt(value) != -1 && Integer.parseInt(value) != -2) {
									linear.height = Utils.dp(context, Integer.parseInt(value));
								} else {
									linear.height = Integer.parseInt(value);
								}
								layoutHeight.text.setText(Utils.getDp(context, linear.height));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		layoutWeight = new AlertButton(context, "Layout weight = ", Integer.toString(linear.weight));
		layoutWeight.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.weight), "Layout weight");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.weight = value;
								layoutWeight.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});
		gravity = new AlertButton(context, "Gravity = ", "...");
		gravity.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertGravityPicker pick = new AlertGravityPicker(context, linear);
				}
			});
	}

	public AlertButton textcolor, textsize, settext;
	public AlertButton toParent, removeView;
	public AlertButton color, corner, corner1, corner2, corner3, corner4, strokeWidth, strokeColor;
	public AlertButton layoutWidth, layoutHeight, layoutWeight, orientation, gravity;
	public AlertButton padding, padding1, padding2, padding3, padding4;
	public AlertButton setid, margin, margin1, margin2, margin3, margin4;
	
	public void showMenu() {
		main.removeAllViews();

		main.addView(toParent);
		main.addView(removeView);
		
		main.addView(setid);
		
		main.addView(settext);
		main.addView(textsize);
		main.addView(textcolor);
		
		main.addView(color);
		main.addView(corner);
		main.addView(corner1);
		main.addView(corner2);
		main.addView(corner3);
		main.addView(corner4);

		main.addView(strokeWidth);
		main.addView(strokeColor);

		main.addView(layoutWidth);
		main.addView(layoutHeight);
		main.addView(layoutWeight);
		main.addView(gravity);

		main.addView(padding);
		main.addView(padding1);
		main.addView(padding2);
		main.addView(padding3);
		main.addView(padding4);
		
		main.addView(margin);
		main.addView(margin1);
		main.addView(margin2);
		main.addView(margin3);
		main.addView(margin4);

		create();
		show();
	}
}

class EditorTextView extends TextView {
	Context context;
	public ArrayList<View> childs = new ArrayList<>();

	public EditorLinearLayout parent = null;
	
	public int width = -2;
	public int height = -2;
	public int weight = 0;

	public int gravity = 0;

	public int color = Color.TRANSPARENT;
	public float[] corner = new float[] {0, 0, 0, 0};

	public int stroke_width = 1;
	public int stroke_color = 0;

	public float text_size = 13f;
	public int text_color = Color.BLACK;
	
	public String text = "TextView";
	public String id = null;
	
	public int[] padding = {0, 0, 0, 0};
	public int[] margin = {0, 0, 0, 0};

	public int getIndex() {
		if (parent == null) return -1;
		return parent.childs.indexOf(this);
	}

	public EditorTextView(Context context) {
		super(context);
		this.context = context;

		gravity = Gravity.CENTER;
		padding = new int[]{5,5,5,5};
		
		update();
	}

	public void edit() {
		AlertSettingTextView alert = new AlertSettingTextView(context, this);
		alert.showMenu();
	}

	public void update() {

		setText(text);
		setTypeface(Utils.font(context));
		setTextSize(text_size);
		setTextColor(text_color);
		
		setPadding(padding[0], padding[1], padding[2], padding[3]);
		setGravity(gravity);

		GradientDrawable design = new GradientDrawable();
		design.setColor(color);
		design.setCornerRadii(new float[] {corner[0], corner[0], corner[1], corner[1], corner[2], corner[2], corner[3], corner[3]});
		design.setStroke(stroke_width, stroke_color);
		setBackgroundDrawable(design);

		LayoutParams lp = new LayoutParams(width, height, weight);
		lp.leftMargin   = margin[0];
		lp.topMargin    = margin[1];
		lp.rightMargin  = margin[2];
		lp.bottomMargin = margin[3];
		setLayoutParams(lp);
	}
}

class AlertSettingImageView extends Dialog {
	Context context;

	public EditorImageView linear;
	public ScrollView scroll;
	public LinearLayout main;

	public AlertSettingImageView(final Context context, final EditorImageView linear) {
		super(context);
		this.context = context;
		this.linear = linear;

		scroll = new ScrollView(context);
		scroll.setFillViewport(true);

		main = new LinearLayout(context);
		main.setOrientation(LinearLayout.VERTICAL);
		scroll.addView(main, Utils.dp(context, 300), -1);

		setContentView(scroll);

		toParent = new AlertButton(context, "To parent", "");
		toParent.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					dismiss();
					linear.parent.edit();
				}
			});

		removeView = new AlertButton(context, "Remove this view", "");
		removeView.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					dismiss();
					linear.parent.childs.remove(linear);
					linear.parent.update();
				}
			});
		
		color = new AlertButton(context, "Background color = ", Utils.getHex(linear.color));
		color.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v){
					final AlertColor colorp = new AlertColor(context);
					colorp.inp.button.setOnClickListener(new View.OnClickListener() {
							public void onClick(View v) {
								colorp.dismiss();
								int c = Color.parseColor(colorp.inp.edittext.getText().toString().trim());
								color.text.setText(Utils.getHex(c));
								linear.color = c;
								linear.update();
							}
						});
					colorp.show();
				}
			});

		corner = new AlertButton(context, "Corner = ", Float.toString(linear.corner[0]));
		corner.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Float.toString(0), "Corner");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								float value = Float.parseFloat(output);
								value = value < 0 ? 0 : value;
								linear.corner[0] = value;
								linear.corner[1] = value;
								linear.corner[2] = value;
								linear.corner[3] = value;

								corner1.text.setText(Float.toString(value));
								corner2.text.setText(Float.toString(value));
								corner3.text.setText(Float.toString(value));
								corner4.text.setText(Float.toString(value));

								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		corner1 = new AlertButton(context, "Corner left-top = ", Float.toString(linear.corner[0]));
		corner1.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Float.toString(linear.corner[0]), "Corner left-top");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								float value = Float.parseFloat(output);
								value = value < 0 ? 0 : value;
								linear.corner[0] = value;
								corner1.text.setText(Float.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		corner2 = new AlertButton(context, "Corner right-top = ", Float.toString(linear.corner[1]));
		corner2.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Float.toString(linear.corner[1]), "Corner right-top");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								float value = Float.parseFloat(output);
								value = value < 0 ? 0 : value;
								linear.corner[1] = value;
								corner2.text.setText(Float.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		corner3 = new AlertButton(context, "Corner right-bottom = ", Float.toString(linear.corner[2]));
		corner3.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Float.toString(linear.corner[2]), "Corner right-bottom");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								float value = Float.parseFloat(output);
								value = value < 0 ? 0 : value;
								linear.corner[2] = value;
								corner3.text.setText(Float.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		corner4 = new AlertButton(context, "Corner left-bottom = ", Float.toString(linear.corner[3]));
		corner4.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Float.toString(linear.corner[3]), "Corner left-bottom");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								float value = Float.parseFloat(output);
								value = value < 0 ? 0 : value;
								linear.corner[3] = value;
								corner4.text.setText(Float.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		padding = new AlertButton(context, "Padding = ", Integer.toString(linear.padding[0]));
		padding.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, "0", "Padding");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.padding[0] = value;
								linear.padding[1] = value;
								linear.padding[2] = value;
								linear.padding[3] = value;

								padding1.text.setText(Integer.toString(value));
								padding2.text.setText(Integer.toString(value));
								padding3.text.setText(Integer.toString(value));
								padding4.text.setText(Integer.toString(value));

								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		padding1 = new AlertButton(context, "Padding left = ", Integer.toString(linear.padding[0]));
		padding1.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.padding[0]), "Padding left");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.padding[0] = value;
								padding1.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		padding2 = new AlertButton(context, "Padding top = ", Integer.toString(linear.padding[1]));
		padding2.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.padding[1]), "Padding top");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.padding[1] = value;
								padding2.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		padding3 = new AlertButton(context, "Padding right = ", Integer.toString(linear.padding[2]));
		padding3.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.padding[2]), "Padding right");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.padding[2] = value;
								padding3.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		padding4 = new AlertButton(context, "Padding bottom = ", Integer.toString(linear.padding[3]));
		padding4.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.padding[3]), "Padding bottom");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.padding[3] = value;
								padding4.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		margin = new AlertButton(context, "Margin = ", Integer.toString(linear.margin[0]));
		margin.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, "0", "Margin");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.margin[0] = value;
								linear.margin[1] = value;
								linear.margin[2] = value;
								linear.margin[3] = value;

								margin1.text.setText(Integer.toString(value));
								margin2.text.setText(Integer.toString(value));
								margin3.text.setText(Integer.toString(value));
								margin4.text.setText(Integer.toString(value));

								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		margin1 = new AlertButton(context, "Margin left = ", Integer.toString(linear.margin[0]));
		margin1.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.margin[0]), "Margin left");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.margin[0] = value;
								margin1.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		margin2 = new AlertButton(context, "Margin top = ", Integer.toString(linear.margin[1]));
		margin2.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.margin[1]), "Margin top");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.margin[1] = value;
								margin2.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});


		setid = new AlertButton(context, "ID = ", linear.id);
		setid.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v){
					final AlertInput textset = new AlertInput(context, "", "ID");
					textset.callback = new AlertInput.Callback() {
						public void onPut(String txt) {
							linear.id = txt;
							linear.update();
							setid.text.setText(txt);
						}
					};
				}
			});

		setsrc = new AlertButton(context, "SRC = ", linear.src);
		setsrc.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v){
					final AlertInput textset = new AlertInput(context, "", "SRC");
					textset.callback = new AlertInput.Callback() {
						public void onPut(String txt) {
							linear.src = txt;
							linear.update();
							setsrc.text.setText(txt);
						}
					};
				}
			});
			
		margin3 = new AlertButton(context, "Margin right = ", Integer.toString(linear.margin[2]));
		margin3.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.margin[2]), "Margin right");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.margin[2] = value;
								margin3.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		margin4 = new AlertButton(context, "Margin bottom = ", Integer.toString(linear.margin[3]));
		margin4.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.margin[3]), "Margin bottom");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.margin[3] = value;
								margin4.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		strokeWidth = new AlertButton(context, "Stroke width = ", Integer.toString(linear.stroke_width));
		strokeWidth.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.stroke_width), "Stroke width");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.stroke_width = value;
								strokeWidth.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});



		strokeColor = new AlertButton(context, "Stroke color = ", Utils.getHex(linear.stroke_color));
		strokeColor.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v){
					final AlertColor colorp = new AlertColor(context);
					colorp.inp.button.setOnClickListener(new View.OnClickListener() {
							public void onClick(View v) {
								colorp.dismiss();
								int c = Color.parseColor(colorp.inp.edittext.getText().toString().trim());
								strokeColor.text.setText(Utils.getHex(c));
								linear.stroke_color = c;
								linear.update();
							}
						});
					colorp.show();
				}
			});

		layoutWidth = new AlertButton(context, "Layout width = ", Utils.getDp(context, linear.width));
		layoutWidth.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					String inputhint = linear.width < 0 ? Integer.toString(linear.width) : Integer.toString(Utils.pd(context, linear.width));
					AlertInput input = new AlertInput(context, inputhint, "Layout width");
					input.callback = new AlertInput.Callback() {
						public void onPut(String value) {
							try {
								if (Integer.parseInt(value) != -1 && Integer.parseInt(value) != -2) {
									linear.width = Utils.dp(context, Integer.parseInt(value));
								} else {
									linear.width = Integer.parseInt(value);
								}
								layoutWidth.text.setText(Utils.getDp(context, linear.width));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		layoutHeight = new AlertButton(context, "Layout height = ", Utils.getDp(context, linear.height));
		layoutHeight.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					String inputhint = linear.height < 0 ? Integer.toString(linear.height) : Integer.toString(Utils.pd(context, linear.height));
					AlertInput input = new AlertInput(context, inputhint, "Layout height");
					input.callback = new AlertInput.Callback() {
						public void onPut(String value) {
							try {
								if (Integer.parseInt(value) != -1 && Integer.parseInt(value) != -2) {
									linear.height = Utils.dp(context, Integer.parseInt(value));
								} else {
									linear.height = Integer.parseInt(value);
								}
								layoutHeight.text.setText(Utils.getDp(context, linear.height));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});

		layoutWeight = new AlertButton(context, "Layout weight = ", Integer.toString(linear.weight));
		layoutWeight.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput inp = new AlertInput(context, Integer.toString(linear.weight), "Layout weight");
					inp.callback = new AlertInput.Callback() {
						public void onPut(String output) {
							try {
								int value = Integer.parseInt(output);
								value = value < 0 ? 0 : value;
								linear.weight = value;
								layoutWeight.text.setText(Integer.toString(value));
								linear.update();
							} catch (Exception e) {}
						}
					};
				}
			});
		
		setvisuals = new AlertButton(context, "Set Picture", "");
		setvisuals.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				((SourceCreatorActivity) (linear.context)).PickPhoto(linear);
			}
		});
	}

	public AlertButton toParent, removeView;
	public AlertButton color, corner, corner1, corner2, corner3, corner4, strokeWidth, strokeColor;
	public AlertButton layoutWidth, layoutHeight, layoutWeight;
	public AlertButton padding, padding1, padding2, padding3, padding4;
	public AlertButton margin, margin1, margin2, margin3, margin4;
	public AlertButton setid, setvisuals, setsrc;

	public void showMenu() {
		main.removeAllViews();

		if (linear.parent != null) {
			main.addView(toParent);
			main.addView(removeView);
		}

		main.addView(setid);

		main.addView(setvisuals);
		main.addView(setsrc);
		main.addView(color);

		main.addView(corner);
		main.addView(corner1);
		main.addView(corner2);
		main.addView(corner3);
		main.addView(corner4);

		main.addView(strokeWidth);
		main.addView(strokeColor);

		main.addView(layoutWidth);
		main.addView(layoutHeight);
		main.addView(layoutWeight);
		
		main.addView(padding);
		main.addView(padding1);
		main.addView(padding2);
		main.addView(padding3);
		main.addView(padding4);

		main.addView(margin);
		main.addView(margin1);
		main.addView(margin2);
		main.addView(margin3);
		main.addView(margin4);

		create();
		show();
	}
}


class EditorImageView extends ImageView {
	Context context;
	
	public EditorLinearLayout parent = null;
	
	public int width = -2;
	public int height = -2;
	public int weight = 0;
	
	public String src = "icon.png";
	
	public int colorfilter = 0;
	
	public int color = Color.TRANSPARENT;
	public float[] corner = new float[] {0, 0, 0, 0};

	public int stroke_width = 1;
	public int stroke_color = 0;

	public String id = null;

	public int[] padding = {0, 0, 0, 0};
	public int[] margin = {0, 0, 0, 0};

	public int getIndex() {
		if (parent == null) return -1;
		return parent.childs.indexOf(this);
	}

	public EditorImageView(Context context) {
		super(context);
		this.context = context;
		
		setMinimumHeight(Utils.dp(context, 50));
		setMinimumWidth(Utils.dp(context, 50));

		padding = new int[]{5,5,5,5};
		
		//color = Color.rgb((int)(Math.random()*255), (int)(Math.random()*255), (int)(Math.random()*255));
		stroke_color = Color.BLUE;
		
		update();
	}

	public void edit() {
		AlertSettingImageView al = new AlertSettingImageView((Context) this.context, this);
		al.showMenu();
	}
	
	public void update() {
		
		setPadding(padding[0], padding[1], padding[2], padding[3]);
		
		GradientDrawable design = new GradientDrawable();
		design.setColor(color);
		design.setCornerRadii(new float[] {corner[0], corner[0], corner[1], corner[1], corner[2], corner[2], corner[3], corner[3]});
		design.setStroke(stroke_width, stroke_color);
		setBackgroundDrawable(design);

		LayoutParams lp = new LayoutParams(width, height, weight);
		lp.leftMargin   = margin[0];
		lp.topMargin    = margin[1];
		lp.rightMargin  = margin[2];
		lp.bottomMargin = margin[3];
		setLayoutParams(lp);
		
		//setColorFilter(colorfilter);
	}
}
