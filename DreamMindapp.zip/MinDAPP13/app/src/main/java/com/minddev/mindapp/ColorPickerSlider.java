package com.minddev.mindapp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;

public class ColorPickerSlider extends View {
    static final int COMPONENT_ALPHA = 3;
    static final int COMPONENT_SATURATION = 1;
    static final int COMPONENT_VALUE = 2;
    float HandlePos = 50.0f;
    private float _xDelta;
    Drawable backgroundCheckers = getResources().getDrawable(2131230903);
    private int colorAlpha;
    private float colorHue;
    colorSliderEvent colorListener = null;
    private float colorSaturation;
    private float colorValue;
    int controlledComponent = COMPONENT_SATURATION;
    int handleRad = 0;

	public static interface colorSliderEvent {
		public void onColorChanged(float f);
	}
	
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        RectF rectF = new RectF(0.0f, 0.0f, (float) (getWidth() - (this.handleRad * COMPONENT_VALUE)), (float) getHeight());
        Paint paint = new Paint(COMPONENT_SATURATION);
        paint.setShader(getDisplayGradient(rectF.width()));
        canvas.translate((float) this.handleRad, 0.0f);
        Paint paint2 = new Paint(COMPONENT_SATURATION);
        paint2.setColor(-7829368);
        canvas.drawRect(rectF, paint2);
        rectF.inset((float) dpToPixels(COMPONENT_SATURATION), (float) dpToPixels(COMPONENT_SATURATION));
        paint2.setColor(-3355444);
        canvas.drawRect(rectF, paint2);
        rectF.inset((float) dpToPixels(COMPONENT_SATURATION), (float) dpToPixels(COMPONENT_SATURATION));
        if (this.controlledComponent == COMPONENT_ALPHA) {
            this.backgroundCheckers.setBounds((int) rectF.left, (int) rectF.top, (int) rectF.right, (int) rectF.bottom);
            this.backgroundCheckers.draw(canvas);
        }
        canvas.drawRect(rectF, paint);
        float convertToAbsolutePosition = convertToAbsolutePosition(this.HandlePos);
        paint2 = new Paint(COMPONENT_SATURATION);
        paint2.setColor(-12303292);
        canvas.drawCircle(convertToAbsolutePosition, rectF.centerY(), (float) this.handleRad, paint2);
        paint2.setColor(-1);
        canvas.drawCircle(convertToAbsolutePosition, rectF.centerY(), (float) (this.handleRad - dpToPixels(COMPONENT_SATURATION)), paint2);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        float rawX = motionEvent.getRawX();
        int action = motionEvent.getAction() & 255;
        if (action == 0) {
            this.HandlePos = convertToRelativePosition(motionEvent.getX() - ((float) this.handleRad));
            colorSliderEvent colorsliderevent = this.colorListener;
            if (colorsliderevent != null) {
                colorsliderevent.onColorChanged(this.HandlePos / 100.0f);
            }
            invalidate();
            this._xDelta = rawX - (motionEvent.getX() - ((float) this.handleRad));
        } else if (action == COMPONENT_VALUE) {
            this.HandlePos = convertToRelativePosition(Math.max(Math.min(rawX - this._xDelta, ((float) getWidth()) - (((float) this.handleRad) * 2.0f)), 0.0f));
            colorSliderEvent colorsliderevent2 = this.colorListener;
            if (colorsliderevent2 != null) {
                colorsliderevent2.onColorChanged(this.HandlePos / 100.0f);
            }
            invalidate();
        }
        return true;
    }

    LinearGradient getDisplayGradient(float f) {
        int HSVToColor;
        int i;
        int i2;
        int i3 = this.controlledComponent;
        float[] fArr;
        float[] fArr2;
        if (i3 == COMPONENT_SATURATION) {
            fArr = new float[COMPONENT_ALPHA];
            fArr[0] = this.colorHue;
            fArr[COMPONENT_SATURATION] = 0.0f;
            fArr[COMPONENT_VALUE] = this.colorValue;
            i3 = Color.HSVToColor(fArr);
            fArr2 = new float[COMPONENT_ALPHA];
            fArr2[0] = this.colorHue;
            fArr2[COMPONENT_SATURATION] = 1.0f;
            fArr2[COMPONENT_VALUE] = this.colorValue;
            HSVToColor = Color.HSVToColor(fArr2);
        } else if (i3 == COMPONENT_VALUE) {
            fArr = new float[COMPONENT_ALPHA];
            fArr[0] = this.colorHue;
            fArr[COMPONENT_SATURATION] = this.colorSaturation;
            fArr[COMPONENT_VALUE] = 0.0f;
            i3 = Color.HSVToColor(fArr);
            fArr2 = new float[COMPONENT_ALPHA];
            fArr2[0] = this.colorHue;
            fArr2[COMPONENT_SATURATION] = this.colorSaturation;
            fArr2[COMPONENT_VALUE] = 1.0f;
            HSVToColor = Color.HSVToColor(fArr2);
        } else if (i3 != COMPONENT_ALPHA) {
            i = 0;
            i2 = 0;
            return new LinearGradient(0.0f, 0.0f, f, 0.0f, i, i2, TileMode.CLAMP);
        } else {
            fArr = new float[COMPONENT_ALPHA];
            fArr[0] = this.colorHue;
            fArr[COMPONENT_SATURATION] = this.colorSaturation;
            fArr[COMPONENT_VALUE] = this.colorValue;
            i3 = Color.HSVToColor(0, fArr);
            fArr2 = new float[COMPONENT_ALPHA];
            fArr2[0] = this.colorHue;
            fArr2[COMPONENT_SATURATION] = this.colorSaturation;
            fArr2[COMPONENT_VALUE] = this.colorValue;
            HSVToColor = Color.HSVToColor(255, fArr2);
        }
        i = i3;
        i2 = HSVToColor;
        return new LinearGradient(0.0f, 0.0f, f, 0.0f, i, i2, TileMode.CLAMP);
    }

    public void setColor(int i, float[] fArr) {
        this.colorHue = fArr[0];
        this.colorSaturation = fArr[COMPONENT_SATURATION];
        this.colorValue = fArr[COMPONENT_VALUE];
        this.colorAlpha = i;
        i = this.controlledComponent;
        if (i == COMPONENT_SATURATION) {
            setValue(this.colorSaturation * 100.0f);
        } else if (i == COMPONENT_VALUE) {
            setValue(this.colorValue * 100.0f);
        } else if (i == COMPONENT_ALPHA) {
            setValue((((float) this.colorAlpha) / 255.0f) * 100.0f);
        }
    }

    public ColorPickerSlider(Context context) {
		super(context);
    }

    public void setColor(int i) {
        float[] fArr = new float[COMPONENT_ALPHA];
        Color.colorToHSV(i, fArr);
        setColor(Color.alpha(i), fArr);
    }

    float convertToRelativePosition(float f) {
        return clipVal((f / (((float) getWidth()) - (((float) this.handleRad) * 2.0f))) * 100.0f, 0.0f, 100.0f);
    }

    int dpToPixels(int i) {
        return (int) TypedValue.applyDimension(COMPONENT_SATURATION, (float) i, getResources().getDisplayMetrics());
    }

    public void initialize(int i, int i2) {
        this.controlledComponent = i2;
        setColor(i);
    }

    public void setValue(float f) {
        this.HandlePos = f;
        invalidate();
    }

    float clipVal(float f, float f2, float f3) {
        return Math.max(f2, Math.min(f, f3));
    }

    float convertToAbsolutePosition(float f) {
        return (f / 100.0f) * (((float) getWidth()) - (((float) this.handleRad) * 2.0f));
    }

    protected void onSizeChanged(int i, int i2, int i3, int i4) {
        this.handleRad = Math.min(i, i2) / COMPONENT_ALPHA;
    }

    public void setColorListener(colorSliderEvent colorsliderevent) {
        this.colorListener = colorsliderevent;
    }
}
