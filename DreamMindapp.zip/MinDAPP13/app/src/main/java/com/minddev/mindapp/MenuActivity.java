package com.minddev.mindapp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import android.app.Activity;
import java.util.concurrent.RunnableScheduledFuture;
import com.squareup.picasso.Picasso;
import com.google.gson.JsonArray;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;
import android.preference.EditTextPreference;
import android.service.autofill.OnClickAction;
import android.view.View.OnClickListener;

class PageButton extends LinearLayout {
	Context context;
	public ImageView icon;
	
	public int checkcolor, uncheckcolor;
	
	public static interface Callback {
		public void onClick();
	}
	public Callback callback;
	
	public void click() {
		if (callback != null) callback.onClick();
	}
	
	public void setChecked(boolean check) {
		icon.setColorFilter(check ? checkcolor : uncheckcolor);
	}
	
	public PageButton(Context context, String src) {
		super(context);
		this.context = context;
		
		checkcolor = Color.parseColor("#BE4ED6");
		uncheckcolor = Color.BLACK;
		
		icon = new ImageView(context);
		{
			Utils.SetAssets(context, icon, src);
			icon.setPadding(15,15,15,15);
			icon.setColorFilter(uncheckcolor);
			
			{
				GradientDrawable grad = new GradientDrawable();
				grad.setCornerRadius(15f);
				grad.setColor(Color.WHITE);
				icon.setBackgroundDrawable(grad);
			}
		}
		
		setOrientation(LinearLayout.VERTICAL);
		addView(icon, Utils.dp(context, 45), Utils.dp(context, 45));
		
		setGravity(Gravity.CENTER);
		setLayoutParams(new LayoutParams(-1, -1, 1));
		
		setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				click();
			}
		});
	}
}

class SourceItem extends LinearLayout {
	Context context;
	public CardView card;
	public ImageView image;
	public TextView title, creatortitle, likecount;
	public ImageView like;
	public LinearLayout bottom, main, textlayout, likelayout;
	public String src = null;
	
	public void setImage(final String url) {
		Utils.loadImageFromUrl(image, url);
	}
	
	public void setLiked(int count, boolean islike) {
		Utils.SetAssets(context, like, islike ? "like.png" : "unlike.png");
		likecount.setText(Integer.toString(count));
	}
	
	public static interface Callback {
		public void click();
		public void like();
	}
	public Callback callback;
	
	public void click() {
		if (callback != null) callback.click();
	}
	
	public void like() {
		if (callback != null) callback.like();
	}
	
	public SourceItem(Context context, String name, String creator, int likes, String src) {
		super(context);
		this.context = context;
		
		this.src = src;
		
		setOrientation(LinearLayout.VERTICAL);
		
		card = new CardView(context);
		{
			card.setRadius(25f);
			
			image = new ImageView(context);
			{
				GradientDrawable grad = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[] {Color.parseColor("#BE4ED6"), Color.parseColor("#4425FE")});
				image.setBackgroundDrawable(grad);
				
				new ImageFromUrl(image).execute(Utils.host + "img/" + src + "?v=" + Utils.v);
				
				card.addView(image, -1, -1);
			}
			
			main = new LinearLayout(context);
			{
				GradientDrawable grad = new GradientDrawable();
				grad.setColor(Color.rgb(230, 230, 230));
				grad.setCornerRadius(25f);
				main.setBackgroundDrawable(grad);
				main.setOrientation(LinearLayout.VERTICAL);
				
				main.setPadding(15, 15, 15, 0);
				addView(main, -1, -1);
			}
			
			LinearLayout hor = new LinearLayout(context);
			hor.setOrientation(LinearLayout.HORIZONTAL);
			
			textlayout = new LinearLayout(context);
			{ // Texts
				textlayout.setOrientation(LinearLayout.VERTICAL);
				
				title = new TextView(context);
				{
					title.setText(name);
					title.setTextColor(Color.BLACK);
					title.setTextSize(25f);
					title.setGravity(Gravity.BOTTOM);
					title.setPadding(15, 0, 0, 0);
					title.setTypeface(Utils.font(context), Typeface.BOLD);
				}
				
				creatortitle = new TextView(context);
				{
					creatortitle.setText("Creator: " + creator);
					creatortitle.setTextColor(Color.BLACK);
					creatortitle.setTextSize(18f);
					creatortitle.setGravity(Gravity.TOP);
					creatortitle.setPadding(15, 0, 0, 0);
					creatortitle.setTypeface(Utils.font(context));
				}
				
				textlayout.addView(title, new LayoutParams(-1, -1, 1));
				textlayout.addView(creatortitle, new LayoutParams(-1, -1, 1));
				
				hor.addView(textlayout, new LayoutParams(-1, -1, 1));
			}
			
			likelayout = new LinearLayout(context);
			{ // Likes
				likelayout.setOrientation(LinearLayout.VERTICAL);
				likelayout.setGravity(Gravity.CENTER);
				
				like = new ImageView(context);
				{
					like.setPadding(10,20,10,0);
					Utils.SetAssets(context, like, "unlike.png");
					likelayout.addView(like, new LayoutParams(-1, -1, 1));
					
					like.setOnClickListener(new OnClickListener() {
						public void onClick(View v) {
							like();
						}
					});
				}
				
				likecount = new TextView(context);
				{
					likecount.setText(Integer.toString(likes));
					likecount.setTextColor(Color.BLACK);
					likecount.setTextSize(20f);
					likecount.setGravity(Gravity.CENTER);
					likecount.setTypeface(Utils.font(context));
					
					likelayout.addView(likecount, new LayoutParams(-1, -1, 1));
				}
				
				hor.addView(likelayout, Utils.dp(context, 50), -1);
			}
			
			main.addView(card, -1, Utils.dp(context, 200));
			main.addView(hor, -1, -1);
			
		}
		
		setLayoutParams(new LayoutParams(-1, Utils.dp(context, 300)));
		setPadding(25, 25, 25, 25);
		setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				click();
			}
		});
	}
}

public class MenuActivity extends AppCompatActivity {

	public LinearLayout header, avalayout, profilecard, pagebuttons, pagelayout;
	public TextView login;
	
	public ArrayList<View> pages = new ArrayList<>();
	public ArrayList<PageButton> butts = new ArrayList<>();
	
	float corner = 30;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.menu);
		
		initialize();
	}
	
	public void send_download(String src) {
		Intent intent = new Intent(this, DownloadActivity.class);
		intent.putExtra("login", getIntent().getExtras().get("login").toString());
		intent.putExtra("password", getIntent().getExtras().get("password").toString());
		
		intent.putExtra("src", src);
		startActivity(intent);
	}
	
	public void change_pass() {
		final EditText oldpass = (EditText) pages.get(1).findViewById(R.id.passwordold);
		final EditText newpass = (EditText) pages.get(1).findViewById(R.id.passwordnew);
		try {
		AsyncTask.execute(new Runnable() {
			public void run() {
				final String response = Utils.urlRequest(Utils.host + String.format("change_pass?v=%s&login=%s&password=%s&hwid=%s&newpass=%s", Utils.v, getIntent().getExtras().get("login").toString(), oldpass.getText().toString(), Utils.getHwid(getApplicationContext()), newpass.getText().toString()));
				final JsonObject tokens = new Gson().fromJson(response, JsonObject.class);
				
				runOnUiThread(new Runnable() {
					public void run() {
						Utils.log(getApplicationContext(), tokens.get("code").getAsString());
						showPage(0);
						if (tokens.get("type").getAsString().equals("success")) {
							getIntent().getExtras().putString("password", newpass.getText().toString());
						}
					}
				});
			}
		});
		} catch (Exception e) {
			Utils.log(getApplicationContext(), e.toString());
		}
	}
	
	public void updateProfile() {
		profilecard = (LinearLayout) pages.get(1).findViewById(R.id.profilecard);
		
		GradientDrawable ava = new GradientDrawable();
		ava.setCornerRadius(corner);
		ava.setColor(Color.rgb(180, 40, 110));
		
		profilecard.setBackgroundDrawable(ava);

		profilecard.setPadding(5,5,5,5);
		CardView ic = new CardView(this);
		ic.setRadius(corner);

		ImageView imageuser = new ImageView(this);
		JsonObject json = new Gson().fromJson(getIntent().getExtras().get("data").toString(), JsonObject.class);

		new ImageFromUrl(imageuser).execute(Utils.host + "/icon/" + Integer.toString(json.get("avatar").getAsInt()) + "?v=" + Utils.v);

		profilecard.addView(ic, -1, -1);
		ic.addView(imageuser, -1, -1);
		
		LinearLayout menudesign = (LinearLayout) pages.get(1).findViewById(R.id.menudesign);
		{
			GradientDrawable bottom = new GradientDrawable(
				GradientDrawable.Orientation.TL_BR,
				new int[] {Color.parseColor("#BE4ED6"), Color.parseColor("#4425FE")}
			);
			bottom.setCornerRadius(15f);
			menudesign.setBackgroundDrawable(bottom);
		}
		
		LinearLayout loginform = (LinearLayout) pages.get(1).findViewById(R.id.loginform);
		{
			GradientDrawable log = new GradientDrawable();
			log.setCornerRadius(10f);
			log.setColor(Color.WHITE);
			loginform.setBackgroundDrawable(log);
		}

		LinearLayout passform = (LinearLayout) pages.get(1).findViewById(R.id.passform);
		{
			GradientDrawable pas = new GradientDrawable();
			pas.setCornerRadius(10f);
			pas.setColor(Color.WHITE);
			passform.setBackgroundDrawable(pas);
		}
		
		Button changepass = (Button) pages.get(1).findViewById(R.id.changepass);
		{
			GradientDrawable grad = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[] {Color.parseColor("#BE4ED6"), Color.parseColor("#4425FE")});
			grad.setCornerRadius(15f);
			changepass.setBackgroundDrawable(grad);
			changepass.setOnClickListener(new OnClickListener() {
				public void onClick(View v) {
					change_pass();
				}
			});
		}
		
		LinearLayout premdesign = (LinearLayout) pages.get(1).findViewById(R.id.premdesign);
		{
			GradientDrawable bottom = new GradientDrawable(
				GradientDrawable.Orientation.TL_BR,
				new int[] {Color.parseColor("#BE4ED6"), Color.parseColor("#4425FE")}
			);
			bottom.setCornerRadius(15f);
			premdesign.setBackgroundDrawable(bottom);
		}

		LinearLayout premform = (LinearLayout) pages.get(1).findViewById(R.id.premform);
		{
			GradientDrawable log = new GradientDrawable();
			log.setCornerRadius(10f);
			log.setColor(Color.WHITE);
			premform.setBackgroundDrawable(log);
		}
		
		Button actpromo = (Button) pages.get(1).findViewById(R.id.actpromo);
		{
			GradientDrawable grad = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[] {Color.parseColor("#BE4ED6"), Color.parseColor("#4425FE")});
			grad.setCornerRadius(15f);
			actpromo.setBackgroundDrawable(grad);
		}
		
		((TextView) pages.get(1).findViewById(R.id.profilenick)).setText("Login: " + getIntent().getExtras().get("login").toString());
		((TextView) pages.get(1).findViewById(R.id.profilehwid)).setText("HWID: " + Utils.getHwid(getApplicationContext()));
	}
	
	public void updateSources() {
		final LinearLayout sourcelist = (LinearLayout) findViewById(R.id.sources);
		
		AsyncTask.execute(new Runnable() {
			public void run() {
				final String resp = Utils.urlRequest(Utils.host + String.format("get_sources?v=%s&login=%s&password=%s&hwid=%s", Utils.v, getIntent().getExtras().get("login"), getIntent().getExtras().get("password"), Utils.getHwid(getApplicationContext())));
				final JsonObject tokens = new Gson().fromJson(resp, JsonObject.class);
				runOnUiThread(new Runnable() {
					public void run() {
						sourcelist.removeAllViews();
						try {
						if (tokens.get("type").getAsString().equals("success")) {
							JsonArray sources = tokens.get("data").getAsJsonArray();
							for (int i = 0; i < sources.size(); i++) {
								JsonObject source = sources.get(i).getAsJsonObject();
								
								final String src = source.get("src").getAsString();
								final String name = source.get("data").getAsJsonObject().get("name").getAsString();
								final String author = source.get("data").getAsJsonObject().get("author").getAsString();
								final String desc = source.get("data").getAsJsonObject().get("description").getAsString();
								final int likes = source.get("data").getAsJsonObject().get("likes").getAsJsonArray().size();
								final boolean islike = source.get("islike").getAsBoolean();
								
								final SourceItem item = new SourceItem(getApplicationContext(), name, author, likes, src);
								sourcelist.addView(item);
								
								item.setLiked(likes, islike);
								item.callback = new SourceItem.Callback() {
									public void click() {
										send_download(src);
									}
									
									public void like() {
										AsyncTask.execute(new Runnable() {
											public void run() {
												final String response = Utils.urlRequest(Utils.host + String.format("like?v=%s&src=%s&login=%s&password=%s&hwid=%s", Utils.v, src, getIntent().getExtras().get("login"), getIntent().getExtras().get("password"), Utils.getHwid(getApplicationContext())));
												final JsonObject token = new Gson().fromJson(response, JsonObject.class);
												
												runOnUiThread(new Runnable() {
													public void run() {
														if (token.get("type").getAsString().equals("success")) {
															item.setLiked(token.get("data").getAsJsonObject().get("count").getAsInt(), token.get("data").getAsJsonObject().get("islike").getAsBoolean());
															Utils.anim(item.like, 400);
														} else {
															Utils.log(getApplicationContext(), token.get("code").getAsString());
														}
													}
												});
											}
										});
									}
								};
							}
						} else {
							Utils.log(getApplicationContext(), tokens.get("code").getAsString());
						}
						} catch (Exception e) {
							Utils.log(getApplicationContext(), e.toString());
						}
					}
				});
			}
		});
	}
	
	public View newPage(int layoutid, String src) {
		LayoutInflater factory = LayoutInflater.from(this);
		final View page = factory.inflate(layoutid, null);
		final PageButton button = new PageButton(this, src);
		pagebuttons.addView(button);
		
		pagelayout.addView(page, -1, -1);
		page.setVisibility(View.GONE);
		
		final int pageid = pages.size();
		pages.add(page);
		butts.add(button);
		
		button.callback = new PageButton.Callback() {
			public void onClick() {
				showPage(pageid);
			}
		};
		
		return page;
	}
	
	public void showPage(int id) {
		for (View page: pages) {
			page.setVisibility(View.GONE);
		}
		for (PageButton page: butts) {
			page.setChecked(false);
		}
		pages.get(id).setVisibility(View.VISIBLE);
		butts.get(id).setChecked(true);
		Utils.anim(pages.get(id), 400);
		
		if (id == 0) {
			updateSources();
		}
		if (id == 1) {
			updateProfile();
		}
	}
	
	public void initialize() {
		header = (LinearLayout) findViewById(R.id.header);
		avalayout = (LinearLayout) findViewById(R.id.avalayout);
		login = (TextView) findViewById(R.id.logintext);
		pagebuttons = (LinearLayout) findViewById(R.id.pagebuttons);
		pagelayout = (LinearLayout) findViewById(R.id.page);
		
		{ // Header design
			GradientDrawable bottom = new GradientDrawable(
				GradientDrawable.Orientation.TL_BR,
				new int[] {Color.parseColor("#BE4ED6"), Color.parseColor("#4425FE")}
			);
			bottom.setCornerRadii(new float[] {0, 0, 0, 0, 0, 0, corner, corner});
			header.setBackgroundDrawable(bottom);
			
			{ // Ava layout
				GradientDrawable ava = new GradientDrawable();
				ava.setCornerRadius(corner);
				ava.setColor(Color.WHITE);
				avalayout.setBackgroundDrawable(ava);
				
				avalayout.setPadding(2,2,2,2);
				CardView ic = new CardView(this);
				ic.setRadius(corner);
				
				ImageView imageuser = new ImageView(this);
				JsonObject json = new Gson().fromJson(getIntent().getExtras().get("data").toString(), JsonObject.class);
				
				new ImageFromUrl(imageuser).execute(Utils.host + "/icon/" + Integer.toString(json.get("avatar").getAsInt()) + "?v=" + Utils.v);
				
				avalayout.addView(ic, -1, -1);
				ic.addView(imageuser, -1, -1);
			}
		}
		
		{ // Page buttom buttons
			GradientDrawable bottom = new GradientDrawable(
				GradientDrawable.Orientation.TL_BR,
				new int[] {Color.parseColor("#BE4ED6"), Color.parseColor("#4425FE")}
			);
			bottom.setCornerRadii(new float[] {10, 10, 10, 10, 0, 0, 0, 0});
			pagebuttons.setBackgroundDrawable(bottom);
		}
		
		{ // Load info
			JsonObject tokens = new Gson().fromJson(getIntent().getExtras().get("data").toString(), JsonObject.class);
			login.setText("Login: " + tokens.get("nick").getAsString());
			((TextView) findViewById(R.id.version)).setText("Version: " + Utils.v);
		}
		
		newPage(R.layout.sourceslist, "sources.png");
		
		newPage(R.layout.profile, "profile.png");
		
		PageButton editor = new PageButton(this, "editor.png");
		butts.add(editor);
		pagebuttons.addView(editor);
		final Intent edit = new Intent(this, SourceCreatorActivity.class);
		editor.callback = new PageButton.Callback() {
			public void onClick() {
				startActivity(edit);
			}
		};
		
		showPage(0);
	}
	
}
