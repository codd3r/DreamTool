package com.minddev.mindapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import android.net.Uri;
import com.minddev.mindapp.Components.CustomCheckBox;
import android.graphics.drawable.shapes.Shape;
import android.graphics.drawable.Drawable;

public class MainActivity extends AppCompatActivity {

	public LinearLayout buttlayout, bottomradius;
	public RelativeLayout framelayout;
	public Button login;
	public EditText login1, password1;
	SharedPreferences save;
	CustomCheckBox checkbox;
	
	public LinearLayout loginform, passform;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		save = getSharedPreferences("save", Context.MODE_PRIVATE);
		
		setButtonLogin();
		
		((TextView) findViewById(R.id.buysub)).setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/mindapp_shopbot")));
			}
		});
    }
	
	public void send_auth() {
		final String user = login1.getText().toString();
		final String password = password1.getText().toString();
		final String hwid = Utils.getHwid(this);
		
		final Intent intent = new Intent(this, MenuActivity.class);
		
		AsyncTask.execute(new Runnable() {
			public void run() {
				try {
					final String response = Utils.urlRequest(String.format("%sauth?v=%s&login=%s&password=%s&hwid=%s", Utils.host, Utils.v, user, password, hwid));
					final JsonObject tokens = new Gson().fromJson(response, JsonObject.class);
				
					runOnUiThread(new Runnable() {
						public void run() {
							if (tokens.get("type").getAsString().equals("success")) {
								Utils.log(getApplicationContext(), "Добро пожаловать");
								intent.putExtra("data", tokens.get("code").getAsJsonObject().toString());
								intent.putExtra("login", user);
								intent.putExtra("password", password);
								SharedPreferences.Editor editor = save.edit();
								editor.putString("login", user);
								editor.putString("password", password);
								if (checkbox.isChecked) {
									editor.putString("auth_login", user);
									editor.putString("auth_password", password);
								}
								editor.commit();
								startActivity(intent);
							} else {
								Utils.log(getApplicationContext(), tokens.get("code").getAsString());
							}
						}
					});
				} catch (Exception e) {
					runOnUiThread(new Runnable() {
						public void run() {
							Utils.log(getApplicationContext(), "Сервера отключены");
						}
					});
				}
			}
		});
	}
	
	public void setButtonLogin() {
		buttlayout = (LinearLayout) findViewById(R.id.buttlayout);
		
		framelayout = new RelativeLayout(this);
		
		bottomradius = new LinearLayout(this);
		{
			GradientDrawable bottom = new GradientDrawable(
				GradientDrawable.Orientation.TL_BR,
				new int[] {Color.parseColor("#BE4ED6"), Color.parseColor("#4425FE")}
			);
			
			bottom.setCornerRadii(new float[] {0, 0, 0, 0, 80, 80, 80, 80});
			bottomradius.setBackgroundDrawable(bottom);
		}
		
		RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Utils.dp(this, 570));
		params.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
		
		LayoutInflater factory = LayoutInflater.from(this);
		View view = factory.inflate(R.layout.mainpanel, null);
		login1 = (EditText) view.findViewById(R.id.login1);
		password1 = (EditText) view.findViewById(R.id.password1);
		
		login1.setText(save.getString("auth_login", ""));
		password1.setText(save.getString("auth_password", ""));
		
		RelativeLayout.LayoutParams params2 = new RelativeLayout.LayoutParams(Utils.dp(this, 250), Utils.dp(this, 60));
		params2.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM, RelativeLayout.TRUE);
		params2.addRule(RelativeLayout.CENTER_HORIZONTAL, RelativeLayout.TRUE);
		
		RelativeLayout.LayoutParams params3 = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Utils.dp(this, 540));
		params3.addRule(RelativeLayout.CENTER_HORIZONTAL, RelativeLayout.TRUE);
		
		login = new Button(this);
		{ // Login button design
			GradientDrawable design = new GradientDrawable(
				GradientDrawable.Orientation.TL_BR,
				new int[] {Color.parseColor("#9334F3"), Color.parseColor("#BE4ED7")}
			);
			
			design.setCornerRadius(40f);
			login.setBackgroundDrawable(design);
			
			login.setText("Login");
			login.setTextColor(Color.WHITE);
			login.setTextSize(25f);
			login.setTypeface(getResources().getFont(R.font.font));
			
			login.setOnClickListener(new OnClickListener() {
				public void onClick(View v) {
					send_auth();
				}
			});
		}
		
		loginform = (LinearLayout) view.findViewById(R.id.loginform);
		{
			GradientDrawable log = new GradientDrawable();
			log.setCornerRadius(10f);
			log.setColor(Color.WHITE);
			loginform.setBackgroundDrawable(log);
		}
		
		passform = (LinearLayout) view.findViewById(R.id.passform);
		{
			GradientDrawable pas = new GradientDrawable();
			pas.setCornerRadius(10f);
			pas.setColor(Color.WHITE);
			passform.setBackgroundDrawable(pas);
		}
		
		LinearLayout savelayout = (LinearLayout) view.findViewById(R.id.savedata);
		checkbox = new CustomCheckBox(this);
		checkbox.colorMain = Color.WHITE;
		checkbox.setText("Remember me");
		checkbox.title.setTextColor(Color.WHITE);
		
		savelayout.addView(checkbox);
		
		framelayout.addView(bottomradius, params);
		
		framelayout.addView(view, params3);
		
		framelayout.addView(login, params2);
		
		buttlayout.addView(framelayout, -1, -1);
	}
    
}
