package com.minddev.mindapp;
import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.widget.LinearLayout;
import android.widget.TextView;

public class page extends LinearLayout {
	Context context;
	
	public TextView textview3;
	
	public page (Context context) {
		super(context);
		this.context = context;
		
				textview3 = new TextView(context);
			{
				textview3.setText("nsjekwks");
				textview3.setPadding(5, 5, 5, 5);
				textview3.setGravity(17);
			
				GradientDrawable design = new GradientDrawable();
				design.setColor(0);
				design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f });
				design.setStroke(1, 0);
				textview3.setBackgroundDrawable(design);
			
				LayoutParams lp = new LayoutParams(-2, -2, 0);
				lp.leftMargin   = 0;
				lp.topMargin    = 0;
				lp.rightMargin  = 0;
				lp.bottomMargin = 0;
				textview3.setLayoutParams(lp);
				textview3.setTextColor(-9765072);
				textview3.setTextSize(20.0f);
				
			}
	}
}
