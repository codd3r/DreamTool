package com.minddev.mindapp;

import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.net.URI;
import android.net.Uri;
import android.support.v4.graphics.ColorUtils;
import android.widget.ScrollView;
import android.widget.TableRow.LayoutParams;
import android.graphics.Typeface;
import android.widget.CheckBox;

class Picker extends LinearLayout {
	Context context;
	public int index = 1;
	public ArrayList<LinearLayout> buttons = new ArrayList<>();
	
	public void pick(int id) {
		index = id+1;
		for (LinearLayout butt: buttons) {
			butt.setBackgroundColor(Color.rgb(140, 140, 140));
		}
		buttons.get(id).setBackgroundColor(Color.rgb(180, 40, 160));
	}
	
	public Picker(Context context, String[] whys) {
		super(context);
		this.context = context;
		
		for (String why: whys) {
			final LinearLayout button = new LinearLayout(context);
			button.setBackgroundColor(Color.rgb(140, 140, 140));
			
			TextView title = new TextView(context);
			title.setTextColor(Color.WHITE);
			title.setTextSize(13f);
			title.setText(why);
			title.setGravity(Gravity.CENTER);
			title.setTypeface(Utils.font(context));
			
			final int iid = buttons.size();
			button.setOnClickListener(new OnClickListener() {
				public void onClick(View v) {
					pick(iid);
				}
			});
			
			button.addView(title, -1, -1);
			buttons.add(button);
			addView(button, new LayoutParams(-1, -1, 1));
		}
		
		pick(0);
		setOrientation(LinearLayout.HORIZONTAL);
		setLayoutParams(new LayoutParams(-1, Utils.dp(context, 35)));
	}
}

class Builder extends Dialog {
	Context context;
	Picker type, button1, slider1, input1, picker, open;
	
	LinearLayout main;
	
	public Builder(Context context){
		super(context);
		this.context = context;
		
		main = new LinearLayout(context);
		{
			main.setOrientation(LinearLayout.VERTICAL);
		}
		
		type = new Picker(context, new String[] {"Menu scroll", "Menu pages", "Menu underpages"});
		{
			main.addView(type);
		}
		
		button1 = new Picker(context, new String[] {"Swith", "CheckBox", "ON/OFF"});
		{
			main.addView(button1);
		}
		
		slider1 = new Picker(context, new String[] {"Slider 1 line", "Slider 2 line"});
		{
			main.addView(slider1);
		}
		
		Button compile = new Button(context);
		{
			compile.setBackgroundColor(Color.rgb(110, 110, 110));
			compile.setTextColor(Color.WHITE);
			compile.setTextSize(11f);
			compile.setText("Build");
			compile.setGravity(Gravity.CENTER);
			compile.setTypeface(Utils.font(context));
			
			main.addView(compile, -1, Utils.dp(context, 35));
			
			compile.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					dismiss();
					callback.onBuild(type.index, button1.index, slider1.index);
				}
			});
		}
		
		setContentView(main);
		Window window = getWindow();
		
		WindowManager.LayoutParams params = window.getAttributes();
		params.width = Utils.dp(context, 400);
		window.setAttributes(params);
		show();
	}
	
	public static interface Callback {
		public void onBuild(int mt, int bt, int st);
	}
	public Callback callback;
}

public class SourceCreatorActivity extends AppCompatActivity {

	public EditorLinearLayout main_linear, second_linear, under_linear;
	public static int objId = 0;
	SharedPreferences save;
	
	public ArrayList<View> get_child(EditorLinearLayout edit) {
		ArrayList<View> childs = new ArrayList<>();
		
		for (View view: edit.childs) {
			childs.add(view);
			if (view instanceof EditorLinearLayout) {
				childs.addAll(get_child((EditorLinearLayout)view));
			}
		}
		
		return childs;
	}
	
	Button goto1, goto2, goto3, copy1, copy2, copy3, slist;
	
	EditorImageView pickimg;
	public void PickPhoto(EditorImageView img) {
		Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
		intent.setType("image/*");
		pickimg = img;
		startActivityForResult(intent, 1001);
		
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		
		switch (requestCode) {
			case 1001:
				if (resultCode == Activity.RESULT_OK) {
					if (data != null) {
						pickimg.setImageURI(data.getData());
					}
				}
				break;
		}
	}
	
	
	
	public void loadSource(EditorLinearLayout lay, String data) {
		
		if (!data.equals(".")) {
			lay.childs.clear();
			lay.removeAllViews();
			lay.update();
			
			final HashMap<String, View> ids = new HashMap<>();
			ids.put(lay.id, lay);
			
			JsonArray layouts = new Gson().fromJson(data, JsonArray.class);
			
			for (int i = 0; i < layouts.size(); i++) {
				final JsonObject layout =layouts.get(i).getAsJsonObject();
				try {
					
				if (layout.get("type").getAsString().equals("linear")) {
					
					final EditorLinearLayout linear = ((EditorLinearLayout) ids.get(layout.get("parent").getAsString())).addLinear();
					linear.orientation = layout.get("orientation").getAsInt();
					linear.id = layout.get("id").getAsString();
					linear.parent = (EditorLinearLayout)ids.get(layout.get("parent").getAsString());
					linear.width = layout.get("width").getAsInt();
					linear.height = layout.get("height").getAsInt();
					linear.weight = layout.get("weight").getAsInt();
					linear.gravity = layout.get("gravity").getAsInt();
					linear.color = layout.get("color").getAsInt();
					
					float[] corner = {layout.get("corner").getAsJsonArray().get(0).getAsFloat(), layout.get("corner").getAsJsonArray().get(1).getAsFloat(), layout.get("corner").getAsJsonArray().get(2).getAsFloat(), layout.get("corner").getAsJsonArray().get(3).getAsFloat()};
					linear.corner = corner;
					linear.stroke_width = layout.get("stroke_width").getAsInt();
					linear.stroke_color = layout.get("stroke_color").getAsInt();
					
					int[] margin = {layout.get("margin").getAsJsonArray().get(0).getAsInt(), layout.get("margin").getAsJsonArray().get(1).getAsInt(), layout.get("margin").getAsJsonArray().get(2).getAsInt(), layout.get("margin").getAsJsonArray().get(3).getAsInt()};
					linear.margin = margin;
					
					int[] padding = {layout.get("padding").getAsJsonArray().get(0).getAsInt(), layout.get("padding").getAsJsonArray().get(1).getAsInt(), layout.get("padding").getAsJsonArray().get(2).getAsInt(), layout.get("padding").getAsJsonArray().get(3).getAsInt()};
					linear.padding = padding;
					
					linear.update();
					
					ids.put(layout.get("id").getAsString(), linear);
				} else if (layout.get("type").getAsString().equals("textview")) {

					final EditorTextView linear = ((EditorLinearLayout) ids.get(layout.get("parent").getAsString())).addTextView();
					linear.width = layout.get("width").getAsInt();
					linear.height = layout.get("height").getAsInt();
					linear.weight = layout.get("weight").getAsInt();
					linear.gravity = layout.get("gravity").getAsInt();
					linear.color = layout.get("color").getAsInt();
					linear.text = layout.get("text").getAsString();
					linear.text_color = layout.get("textcolor").getAsInt();
					linear.text_size = layout.get("textsize").getAsFloat();
					linear.id = layout.get("id").getAsString();
					linear.parent = (EditorLinearLayout)ids.get(layout.get("parent").getAsString());
					
					float[] corner = {layout.get("corner").getAsJsonArray().get(0).getAsFloat(), layout.get("corner").getAsJsonArray().get(1).getAsFloat(), layout.get("corner").getAsJsonArray().get(2).getAsFloat(), layout.get("corner").getAsJsonArray().get(3).getAsFloat()};
					linear.corner = corner;
					linear.stroke_width = layout.get("stroke_width").getAsInt();
					linear.stroke_color = layout.get("stroke_color").getAsInt();

					int[] margin = {layout.get("margin").getAsJsonArray().get(0).getAsInt(), layout.get("margin").getAsJsonArray().get(1).getAsInt(), layout.get("margin").getAsJsonArray().get(2).getAsInt(), layout.get("margin").getAsJsonArray().get(3).getAsInt()};
					linear.margin = margin;

					int[] padding = {layout.get("padding").getAsJsonArray().get(0).getAsInt(), layout.get("padding").getAsJsonArray().get(1).getAsInt(), layout.get("padding").getAsJsonArray().get(2).getAsInt(), layout.get("padding").getAsJsonArray().get(3).getAsInt()};
					linear.padding = padding;

					linear.update();

					ids.put(layout.get("id").getAsString(), linear);
				} else if (layout.get("type").getAsString().equals("imageview")) {

					final EditorImageView linear = ((EditorLinearLayout) ids.get(layout.get("parent").getAsString())).addImage();
					linear.width = layout.get("width").getAsInt();
					linear.height = layout.get("height").getAsInt();
					linear.weight = layout.get("weight").getAsInt();
					linear.color = layout.get("color").getAsInt();
					linear.src = layout.get("src").getAsString();
					
					float[] corner = {layout.get("corner").getAsJsonArray().get(0).getAsFloat(), layout.get("corner").getAsJsonArray().get(1).getAsFloat(), layout.get("corner").getAsJsonArray().get(2).getAsFloat(), layout.get("corner").getAsJsonArray().get(3).getAsFloat()};
					linear.corner = corner;
					linear.stroke_width = layout.get("stroke_width").getAsInt();
					linear.stroke_color = layout.get("stroke_color").getAsInt();
					linear.id = layout.get("id").getAsString();
					linear.parent = (EditorLinearLayout)ids.get(layout.get("parent").getAsString());
					
					int[] margin = {layout.get("margin").getAsJsonArray().get(0).getAsInt(), layout.get("margin").getAsJsonArray().get(1).getAsInt(), layout.get("margin").getAsJsonArray().get(2).getAsInt(), layout.get("margin").getAsJsonArray().get(3).getAsInt()};
					linear.margin = margin;

					int[] padding = {layout.get("padding").getAsJsonArray().get(0).getAsInt(), layout.get("padding").getAsJsonArray().get(1).getAsInt(), layout.get("padding").getAsJsonArray().get(2).getAsInt(), layout.get("padding").getAsJsonArray().get(3).getAsInt()};
					linear.padding = padding;

					linear.update();

					ids.put(layout.get("id").getAsString(), linear);
				}
				
				} catch (Exception e) {
					Utils.log(this, e.toString());
				}
			}
			
			Utils.log(this, "complete");
		}
		
		lay.update();
	}
	
	public void setSource() {
		AlertInput al = new AlertInput(this, "", "");
		al.callback = new AlertInput.Callback() {
			public void onPut(String data) {
				SharedPreferences.Editor edit = save.edit();
				edit.putString("data", data);
				edit.commit();
			}
		};
	}
	
	public void setDesign(Button butt) {
		GradientDrawable grad = new GradientDrawable();
		grad.setStroke(2, Color.BLACK);
		grad.setCornerRadius(1f);
		grad.setColor(Color.rgb(220, 220, 220));
		butt.setBackgroundDrawable(grad);
		butt.setTextSize(12f);
		butt.setTextColor(Color.rgb(120, 120, 120));
		butt.setTypeface(Typeface.MONOSPACE);
		butt.setGravity(Gravity.CENTER);
	}
	
	public String get_Source(EditorLinearLayout lin) {
		JsonArray mains = new JsonArray();
		
		for (View view: get_child(lin)) {
			JsonObject obj = new JsonObject();
			
			if (view instanceof EditorLinearLayout) {
				EditorLinearLayout linear = (EditorLinearLayout) view;
				
				obj.add("type", new Gson().toJsonTree("linear"));
				obj.add("id", new Gson().toJsonTree(linear.id));
				obj.add("parent", new Gson().toJsonTree(linear.parent.id));
				obj.add("orientation", new Gson().toJsonTree(linear.orientation));
				obj.add("width", new Gson().toJsonTree(linear.width));
				obj.add("height", new Gson().toJsonTree(linear.height));
				obj.add("weight", new Gson().toJsonTree(linear.weight));
				obj.add("gravity", new Gson().toJsonTree(linear.gravity));
				obj.add("color", new Gson().toJsonTree(linear.color));
				obj.add("corner", new Gson().toJsonTree(linear.corner));
				obj.add("stroke_width", new Gson().toJsonTree(linear.stroke_width));
				obj.add("stroke_color", new Gson().toJsonTree(linear.stroke_color));
				obj.add("padding", new Gson().toJsonTree(linear.padding));
				obj.add("margin", new Gson().toJsonTree(linear.margin));
				
				mains.add(obj);
			}
			
			if (view instanceof EditorTextView) {
				EditorTextView linear = (EditorTextView) view;

				obj.add("type", new Gson().toJsonTree("textview"));
				obj.add("id", new Gson().toJsonTree(linear.id));
				obj.add("parent", new Gson().toJsonTree(linear.parent.id));
				obj.add("width", new Gson().toJsonTree(linear.width));
				obj.add("height", new Gson().toJsonTree(linear.height));
				obj.add("weight", new Gson().toJsonTree(linear.weight));
				obj.add("gravity", new Gson().toJsonTree(linear.gravity));
				obj.add("color", new Gson().toJsonTree(linear.color));
				obj.add("corner", new Gson().toJsonTree(linear.corner));
				obj.add("stroke_width", new Gson().toJsonTree(linear.stroke_width));
				obj.add("stroke_color", new Gson().toJsonTree(linear.stroke_color));
				obj.add("padding", new Gson().toJsonTree(linear.padding));
				obj.add("margin", new Gson().toJsonTree(linear.margin));
				obj.add("textcolor", new Gson().toJsonTree(linear.text_color));
				obj.add("textsize", new Gson().toJsonTree(linear.text_size));
				obj.add("text", new Gson().toJsonTree(linear.text));
				
				mains.add(obj);
			}
			
			if (view instanceof EditorImageView) {
				EditorImageView linear = (EditorImageView) view;

				obj.add("type", new Gson().toJsonTree("imageview"));
				obj.add("id", new Gson().toJsonTree(linear.id));
				obj.add("parent", new Gson().toJsonTree(linear.parent.id));
				obj.add("width", new Gson().toJsonTree(linear.width));
				obj.add("height", new Gson().toJsonTree(linear.height));
				obj.add("weight", new Gson().toJsonTree(linear.weight));
				obj.add("color", new Gson().toJsonTree(linear.color));
				obj.add("corner", new Gson().toJsonTree(linear.corner));
				obj.add("stroke_width", new Gson().toJsonTree(linear.stroke_width));
				obj.add("stroke_color", new Gson().toJsonTree(linear.stroke_color));
				obj.add("padding", new Gson().toJsonTree(linear.padding));
				obj.add("margin", new Gson().toJsonTree(linear.margin));
				obj.add("colorfilter", new Gson().toJsonTree(linear.colorfilter));
				obj.add("src", new Gson().toJsonTree(linear.src));
				
				mains.add(obj);
			}
		}
		
		return mains.toString();
	}
	
	public void openSourceList() {
		new SaveDialog(this);
	}
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.editor);
		
		save = getSharedPreferences("save", Context.MODE_PRIVATE);
		
		main_linear = new EditorLinearLayout(this);
		main_linear.width = -1;
		main_linear.height = -1;
		main_linear.id = "this";
		main_linear.gravity = Gravity.CENTER;
		main_linear.color = Color.WHITE;
		main_linear.update();
		main_linear.addLinear().id = "menulayout";
		
		second_linear = new EditorLinearLayout(this);
		second_linear.width = -1;
		second_linear.height = -1;
		second_linear.id = "null";
		second_linear.gravity = Gravity.CENTER;
		second_linear.color = Color.WHITE;
		second_linear.update();
		second_linear.addLinear().id = "this";
		
		under_linear = new EditorLinearLayout(this);
		under_linear.width = -1;
		under_linear.height = -1;
		under_linear.id = "null";
		under_linear.gravity = Gravity.CENTER;
		under_linear.color = Color.WHITE;
		under_linear.update();
		under_linear.addLinear().id = "this";
		
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		
		((LinearLayout) findViewById(R.id.editorlayout)).addView(main_linear);
		((LinearLayout) findViewById(R.id.editorlayout)).addView(second_linear);
		((LinearLayout) findViewById(R.id.editorlayout)).addView(under_linear);
		
		second_linear.setVisibility(View.GONE);
		under_linear.setVisibility(View.GONE);
		
		goto1 = (Button) findViewById(R.id.goto1);
		goto2 = (Button) findViewById(R.id.goto2);
		goto3 = (Button) findViewById(R.id.goto3);
		copy1 = (Button) findViewById(R.id.copy1);
		copy2 = (Button) findViewById(R.id.copy2);
		copy3 = (Button) findViewById(R.id.copy3);
		slist = (Button) findViewById(R.id.slist);
		
		setDesign(copy1);
		setDesign(copy2);
		setDesign(copy3);
		setDesign(goto1);
		setDesign(goto3);
		setDesign(goto2);
		setDesign(slist);
		setDesign(((Button) findViewById(R.id.buildd)));
		
		slist.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				openSourceList();
			}
		});
		
		copy1.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
				ClipData clip = ClipData.newPlainText(get_Source(main_linear), get_Source(main_linear));
				clipboard.setPrimaryClip(clip);
				Utils.log(getApplicationContext(), "Дата сурса скопирована");
			}
		});
		
		copy2.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
				ClipData clip = ClipData.newPlainText(get_Source(second_linear), get_Source(second_linear));
				clipboard.setPrimaryClip(clip);
				Utils.log(getApplicationContext(), "Дата сурса #2 скопирована");
			}
		});
		
		copy3.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
				ClipData clip = ClipData.newPlainText(get_Source(under_linear), get_Source(under_linear));
				clipboard.setPrimaryClip(clip);
				Utils.log(getApplicationContext(), "Дата сурса #3 скопирована");
			}
		});
		
		goto1.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				main_linear.setVisibility(View.VISIBLE);
				second_linear.setVisibility(View.GONE);
				under_linear.setVisibility(View.GONE);
			}
		});
		
		goto2.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				main_linear.setVisibility(View.GONE);
				second_linear.setVisibility(View.VISIBLE);
				under_linear.setVisibility(View.GONE);
			}
		});
		
		goto3.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				main_linear.setVisibility(View.GONE);
				second_linear.setVisibility(View.GONE);
				under_linear.setVisibility(View.VISIBLE);
			}
		});
		
		final Activity c = this;
		((Button) findViewById(R.id.buildd)).setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Builder builder = new Builder(c);
				
				builder.callback = new Builder.Callback() {
					public void onBuild(final int mt, final int bt, final int st) {
						String sourceid = "MinDAPP_Editor-" + String.valueOf((int) (Math.random() * 1000000));
						AsyncTask.execute(new Runnable() {
							public void run() {
								JsonObject post = new JsonObject();
								post.add("source", new Gson().toJsonTree(get_Source(main_linear)));
								post.add("page", new Gson().toJsonTree(get_Source(second_linear)));
								post.add("under", new Gson().toJsonTree(get_Source(under_linear)));
								
								post.add("mt", new Gson().toJsonTree(mt));
								post.add("bt", new Gson().toJsonTree(bt));
								post.add("st", new Gson().toJsonTree(st));
								
								String args = String.format("v=%s&login=%s&password=%s&hwid=%s", Utils.v, save.getString("login", ""), save.getString("password", ""), Utils.getHwid(getApplicationContext()));
								Utils.urlRequestPost(Utils.host + "compile?" + args, post.toString());
								
								final String url = Utils.host + "downmaker/" + save.getString("login", "null") + "?" + args;
								runOnUiThread(new Runnable() {
									public void run() {
										Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
										startActivity(intent);
									}
								});
							}
						});
					}
				};
			}
		});
    }
    
}

class SaveDialog extends Dialog {
	Context context;
	
	LinearLayout main, sources, settings;
	ScrollView scroll;
	AlertButton remove, save;
	SharedPreferences data;
	
	public void updateList() {
		String json = data.getString("sources", "[]");
		JsonArray list = new Gson().fromJson(json, JsonArray.class);
		
		sources.removeAllViews();
		
		for (int i = 0; i < list.size(); i++) {
			final JsonObject obj = list.get(i).getAsJsonObject();
			
			AlertButton button = new AlertButton(context, obj.get("name").getAsString(), " - Load");
			button.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					((SourceCreatorActivity) context).loadSource(((SourceCreatorActivity) context).main_linear, obj.get("source").getAsString());
					((SourceCreatorActivity) context).loadSource(((SourceCreatorActivity) context).second_linear, obj.get("page").getAsString());
					((SourceCreatorActivity) context).loadSource(((SourceCreatorActivity) context).under_linear, obj.get("under").getAsString());
					
				}
			});
			sources.addView(button);
		}
	}
	
	public void removeSource(String name) {
		name = name.toLowerCase();
		String json = data.getString("sources", "[]");
		JsonArray list = new Gson().fromJson(json, JsonArray.class);
		
		for (int i = 0; i < list.size(); i++) {
			final JsonObject obj = list.get(i).getAsJsonObject();

			if (obj.get("name").getAsString().toLowerCase().equals(name)) {
				list.remove(obj);
				SharedPreferences.Editor edit = data.edit();
				edit.putString("sources", list.toString());
				edit.commit();
				updateList();
			}
		}
	}
	
	public void saveSource(String n) {
		removeSource(n);
		String json = data.getString("sources", "[]");
		JsonArray list = new Gson().fromJson(json, JsonArray.class);
		
		String sourceData = ((SourceCreatorActivity) context).get_Source(((SourceCreatorActivity) context).main_linear);
		String pageData = ((SourceCreatorActivity) context).get_Source(((SourceCreatorActivity) context).second_linear);
		String underData = ((SourceCreatorActivity) context).get_Source(((SourceCreatorActivity) context).under_linear);
		
		JsonObject obj = new JsonObject();
		obj.add("name", new Gson().toJsonTree(n));
		obj.add("source", new Gson().toJsonTree(sourceData));
		obj.add("page", new Gson().toJsonTree(pageData));
		obj.add("under", new Gson().toJsonTree(underData));
		
		list.add(obj);
		SharedPreferences.Editor edit = data.edit();
		edit.putString("sources", list.toString());
		edit.commit();
		updateList();
	}
	
	public void saveSource2(String n, String c1, String c2, String c3) {
		removeSource(n);
		String json = data.getString("sources", "[]");
		JsonArray list = new Gson().fromJson(json, JsonArray.class);

		String sourceData = c1;
		String pageData = c2;
		String underData = c3;
		
		JsonObject obj = new JsonObject();
		obj.add("name", new Gson().toJsonTree(n));
		obj.add("source", new Gson().toJsonTree(sourceData));
		obj.add("page", new Gson().toJsonTree(pageData));
		obj.add("under", new Gson().toJsonTree(underData));
		
		list.add(obj);
		SharedPreferences.Editor edit = data.edit();
		edit.putString("sources", list.toString());
		edit.commit();
		updateList();
	}
	
	public SaveDialog (final Context context) {
		super(context);
		this.context = context;
		this.data = context.getSharedPreferences("sources", Context.MODE_PRIVATE);
		
		main = new LinearLayout(context);
		{
			main.setOrientation(LinearLayout.VERTICAL);
			
			sources = new LinearLayout(context);
			{
				sources.setOrientation(LinearLayout.VERTICAL);
				sources.setBackgroundColor(Color.rgb(140, 140, 140));
				sources.setPadding(5,5,5,5);
				
				scroll = new ScrollView(context);
				scroll.setFillViewport(true);
				scroll.setPadding(20,20,20,20);
				
				scroll.addView(sources, -1, -1);
			}
			
			settings = new LinearLayout(context);
			{
				settings.setOrientation(LinearLayout.HORIZONTAL);
				
				save = new AlertButton(context, "save ", "source");
				settings.addView(save, new LayoutParams(-1, -1, 1));
				
				remove = new AlertButton(context, "remove ", "source");
				settings.addView(remove, new LayoutParams(-1, -1, 1));
				
			}
			
			save.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput al = new AlertInput(context, "", "Name");
					al.callback = new AlertInput.Callback() {
						public void onPut(String n) {
							saveSource(n);
						}
					};
				}
			});
			
			remove.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput al = new AlertInput(context, "", "Name");
					al.callback = new AlertInput.Callback() {
						public void onPut(String n) {
							removeSource(n);
						}
					};
				}
			});
			
			AlertButton add = new AlertButton(context, "Add = ", "text");
			add.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					AlertInput al = new AlertInput(context, "", "Name");
					al.callback = new AlertInput.Callback() {
						public void onPut(final String n) {
							AlertInput al = new AlertInput(context, "", "Copy 1");
							al.callback = new AlertInput.Callback() {
								public void onPut(final String c1) {
									AlertInput al = new AlertInput(context, "", "Copy 2");
									al.callback = new AlertInput.Callback() {
										public void onPut(final String c2) {
											AlertInput al = new AlertInput(context, "", "Copy 3");
											al.callback = new AlertInput.Callback() {
												public void onPut(final String c3) {
													saveSource2(n, c1, c2, c3);
												}
											};
										}
									};
								}
							};
						}
					};
				}
			});
			
			main.addView(scroll, new LayoutParams(-1, Utils.dp(context, 200), 1));
			main.addView(settings, -1, Utils.dp(context, 35));
			main.addView(add, -1, Utils.dp(context, 35));
		}
		
		setContentView(main);
		
		Window window = getWindow();

		WindowManager.LayoutParams params = window.getAttributes();
		params.width = Utils.dp(context, 350);
		window.setAttributes(params);
		
		updateList();
		
		show();
	}
}
