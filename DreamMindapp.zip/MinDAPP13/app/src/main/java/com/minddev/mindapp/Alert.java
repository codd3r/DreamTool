package com.minddev.mindapp;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ScrollView;
import android.widget.TextView;

class AlertButton extends LinearLayout
 {
	Context context;
	public TextView title, text;

	public AlertButton(Context context, String t, String h) {
		super(context);
		this.context = context;

		GradientDrawable grad = new GradientDrawable();
		grad.setStroke(2, Color.BLACK);
		grad.setCornerRadius(1f);
		grad.setColor(Color.rgb(220, 220, 220));
		setBackgroundDrawable(grad);

		title = new TextView(context);
		{
			title.setText(t);
			title.setTextSize(14f);
			title.setTextColor(Color.rgb(120, 120, 120));
			title.setTypeface(Typeface.MONOSPACE);
			title.setGravity(Gravity.CENTER_VERTICAL);
		}

		text = new TextView(context);
		{
			text.setText(h);
			text.setTextSize(14f);
			text.setTextColor(Color.rgb(100, 100, 100));
			text.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
			text.setGravity(Gravity.CENTER_VERTICAL);
		}

		addView(title, -2, -1);
		addView(text, -1, -1);

		setLayoutParams(new LayoutParams(-1, Utils.dp(context, 30)));
		setGravity(Gravity.CENTER_VERTICAL);
		setPadding(15, 0, 0, 0);
	}
}

class Input extends LinearLayout {
	Context context;
	public EditText edittext;
	public AlertButton button;

	public Input(Context context, String text, String hint) {
		super(context);
		this.context = context;

		GradientDrawable grad = new GradientDrawable();
		grad.setStroke(2, Color.BLACK);
		grad.setCornerRadius(1f);
		grad.setColor(Color.rgb(220, 220, 220));
		setBackgroundDrawable(grad);

		edittext = new EditText(context);
		{
			edittext.setBackgroundColor(Color.TRANSPARENT);
			edittext.setText(text);
			edittext.setHint(hint);
			edittext.setTextSize(14f);
			edittext.setHintTextColor(Color.rgb(150, 150, 150));
			edittext.setTextColor(Color.rgb(120, 120, 120));
			edittext.setTypeface(Typeface.MONOSPACE);
			edittext.setGravity(Gravity.CENTER_VERTICAL);
		}

		button = new AlertButton(context, ">", "");
		button.removeView(button.text);
		button.title.setGravity(Gravity.CENTER);
		button.setGravity(Gravity.CENTER);

		addView(edittext, new LayoutParams(Utils.dp(context, 300), -1, 1));
		addView(button, Utils.dp(context, 50), Utils.dp(context, 50));

		setLayoutParams(new LayoutParams(Utils.dp(context, 350), Utils.dp(context, 50)));
		setGravity(Gravity.CENTER_VERTICAL);
		setPadding(15, 0, 0, 0);
	}
}

class AlertInput extends Dialog {
	Context context;
	public static interface Callback {
		public void onPut(String text);
	}
	public Callback callback;
	public Input input;

	public AlertInput(Context context, String text, String hint) {
		super(context);
		this.context = context;

		input = new Input(context, text, hint);

		setContentView(input);
		show();

		input.button.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					dismiss();
					if (callback != null) callback.onPut(input.edittext.getText().toString());
				}
			});
	}
}

class AlertColor extends Dialog {
	Context context;
	public ColorPicker color;
	public LinearLayout main;
	public Input inp;

	public AlertColor(final Context context) {
		super(context);
		this.context = context;

		main = new LinearLayout(context);
		main.setOrientation(LinearLayout.VERTICAL);

		color = new ColorPicker(context);
		color.setOnColorChangedListener(new ColorPicker.ColorChangedListener() {
				public void colorChange() {
					inp.edittext.setText(Utils.getHex(color.getColor()));
				}
			});
		main.addView(color, Utils.dp(context, 250), Utils.dp(context, 250));
		
		inp = new Input(context, "#FFFFFF", "Hex color");

		main.addView(inp, Utils.dp(context, 250), Utils.dp(context, 35));
		GradientDrawable grad = new GradientDrawable();
		grad.setColor(Color.rgb(180,180,180));
		grad.setStroke(2, Color.rgb(110, 110, 110));
		main.setBackgroundDrawable(grad);

		setContentView(main);
	}
}

class AlertPicker extends Dialog {
	Context context;
	public ScrollView scroll;
	public LinearLayout main;

	public static interface Callback {
		public void pick(int id);
	}
	public Callback callback;

	public AlertPicker(final Context context, final String[][] texts) {
		super(context);
		this.context = context;

		scroll = new ScrollView(context);
		scroll.setFillViewport(true);

		main = new LinearLayout(context);
		main.setOrientation(LinearLayout.VERTICAL);
		scroll.addView(main, Utils.dp(context, 300), -1);

		int id = -1;
		for (String[] text: texts) {
			id++;
			final int buttonId = id;
			final AlertButton button = new AlertButton(context, text[0], text[1]);
			button.setOnClickListener(new View.OnClickListener() {
					public void onClick(View v) {
						if (callback != null) callback.pick(buttonId);
						dismiss();
					}
				});
			main.addView(button, Utils.dp(context, 300), Utils.dp(context, 30));
		}

		setContentView(scroll);

		show();
	}
}

class AlertCheckBox extends LinearLayout {
	Context context;

	public CheckBox checkbox;
	public TextView title;

	public AlertCheckBox(Context context, String text) {
		super(context);
		this.context = context;

		checkbox = new CheckBox(context);

		title = new TextView(context);
		{
			title.setText(text);
			title.setTextSize(14f);
			title.setTextColor(Color.rgb(120, 120, 120));
			title.setTypeface(Typeface.MONOSPACE);
			title.setGravity(Gravity.CENTER_VERTICAL);

			title.setOnClickListener(new OnClickListener() {
					public void onClick(View v) {
						checkbox.setChecked(!checkbox.isChecked());
					}
				});
		}

		GradientDrawable grad = new GradientDrawable();
		grad.setStroke(2, Color.BLACK);
		grad.setCornerRadius(1f);
		grad.setColor(Color.rgb(220, 220, 220));
		setBackgroundDrawable(grad);

		addView(title, new LayoutParams(-1, -1, 1));
		addView(checkbox, Utils.dp(context, 30), -1);

		setLayoutParams(new LayoutParams(-1, Utils.dp(context, 30)));
		setGravity(Gravity.CENTER_VERTICAL);
		setPadding(15, 0, 0, 0);
	}
}

class AlertGravityPicker extends Dialog {
	Context context;
	public AlertCheckBox left, top, right, bottom, center, center_horizontal, center_vertical;
	public AlertButton done;

	public View view;
	public ScrollView scroll;
	public LinearLayout main;

	public AlertGravityPicker(Context context, final View view) {
		super(context);
		this.context = context;
		this.view = view;

		scroll = new ScrollView(context);
		scroll.setFillViewport(true);

		main = new LinearLayout(context);
		main.setOrientation(LinearLayout.VERTICAL);
		scroll.addView(main, Utils.dp(context, 300), -1);

		setContentView(scroll);

		left = new AlertCheckBox(context, "Left");
		top = new AlertCheckBox(context, "Top");
		right = new AlertCheckBox(context, "Right");
		bottom = new AlertCheckBox(context, "Bottom");
		center = new AlertCheckBox(context, "Center");
		center_horizontal = new AlertCheckBox(context, "Center Horizontal");
		center_vertical = new AlertCheckBox(context, "Center Vertical");

		done = new AlertButton(context, "Select", "");
		done.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					dismiss();

					int g1 = left.checkbox.isChecked() ? Gravity.LEFT : 0;
					int g2 = top.checkbox.isChecked() ? Gravity.TOP : 0;
					int g3 = right.checkbox.isChecked() ? Gravity.RIGHT : 0;
					int g4 = bottom.checkbox.isChecked() ? Gravity.BOTTOM : 0;
					int g5 = center.checkbox.isChecked() ? Gravity.CENTER : 0;
					int g6 = center_horizontal.checkbox.isChecked() ? Gravity.CENTER_HORIZONTAL : 0;
					int g7 = center_vertical.checkbox.isChecked() ? Gravity.CENTER_VERTICAL : 0;

					if (view instanceof EditorLinearLayout) {
						((EditorLinearLayout) view).gravity = g1 | g2 | g3 | g4 | g5 | g6 | g7;
						((EditorLinearLayout) view).update();
					}
					
					if (view instanceof EditorTextView) {
						((EditorTextView) view).gravity = g1 | g2 | g3 | g4 | g5 | g6 | g7;
						((EditorTextView) view).update();
					}
				}
			});

		for (AlertCheckBox checkbox: new AlertCheckBox[]{left, top, right, bottom, center, center_horizontal, center_vertical}) {
			main.addView(checkbox, Utils.dp(context, 300), Utils.dp(context, 30));
		}
		main.addView(done);

		show();
	}
}

