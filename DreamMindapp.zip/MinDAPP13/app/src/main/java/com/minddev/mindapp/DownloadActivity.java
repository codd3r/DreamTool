package com.minddev.mindapp;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import android.content.Intent;
import android.net.Uri;

public class DownloadActivity extends AppCompatActivity {

	public TextView name, creator, description, likes;
	public LinearLayout cardlayout;
	public Button download;
	public ImageView image;
	public String urlDownload = null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.download);
		
		initialize();
	}
	
	public void updateInfo() {
		AsyncTask.execute(new Runnable() {
			public void run() {
				final String response = Utils.urlRequest(Utils.host + String.format("source_info?v=%s&login=%s&password=%s&hwid=%s&src=%s", Utils.v, getIntent().getExtras().get("login").toString(), getIntent().getExtras().get("password").toString(), Utils.getHwid(getApplicationContext()), getIntent().getExtras().get("src").toString()));
				final JsonObject tokens = new Gson().fromJson(response, JsonObject.class);
				
				runOnUiThread(new Runnable() {
					public void run() {
						if (tokens.get("type").getAsString().equals("success")) {
							JsonObject info = tokens.get("data").getAsJsonObject();
							name.setText(info.get("name").getAsString());
							creator.setText(info.get("author").getAsString());
							description.setText(info.get("description").getAsString());
							likes.setText(Integer.toString(info.get("likes").getAsInt()));
							
							urlDownload = Utils.host + String.format("download?v=%s&login=%s&password=%s&hwid=%s&src=%s", Utils.v, getIntent().getExtras().get("login").toString(), getIntent().getExtras().get("password").toString(), Utils.getHwid(getApplicationContext()), getIntent().getExtras().get("src").toString());
						} else {
							Utils.log(getApplicationContext(), tokens.get("code").getAsString());
						}
					}
				});
				new ImageFromUrl(image).execute(Utils.host + "img/" + getIntent().getExtras().get("src").toString());
			}
		});
	}
	
	public void initialize() {
		name = (TextView) findViewById(R.id.name);
		creator = (TextView) findViewById(R.id.creator);
		description = (TextView) findViewById(R.id.desc);
		likes = (TextView) findViewById(R.id.likes);
		
		cardlayout = (LinearLayout) findViewById(R.id.card);
		
		download = (Button) findViewById(R.id.download);
		
		CardView card = new CardView(this);
		card.setRadius(25f);
		
		image = new ImageView(this);
		{
			GradientDrawable grad = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[] {Color.parseColor("#BE4ED6"), Color.parseColor("#4425FE")});
			image.setBackgroundDrawable(grad);
			
			cardlayout.addView(card, -1, -1);
			card.addView(image, -1, -1);
		}
		
		{
			GradientDrawable grad = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[] {Color.parseColor("#BE4ED6"), Color.parseColor("#4425FE")});
			grad.setCornerRadius(50f);
			download.setBackgroundDrawable(grad);
		}
		
		updateInfo();
		
		download.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(urlDownload)));
			}
		});
	}
}
