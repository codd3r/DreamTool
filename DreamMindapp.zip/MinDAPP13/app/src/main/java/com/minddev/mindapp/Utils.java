package com.minddev.mindapp;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.Settings.Secure;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import android.widget.ScrollView;

public class Utils {
	
	public static String host = "http://185.212.148.226:5010/";
	public static String v = "1.2";
	public static String getHex(int c) {
		return String.format("#%02x%02x%02x", Color.red(c), Color.green(c), Color.blue(c)).toUpperCase();
	}
	
	public static void writeFile(Context context, File file, String text, String name) {
		try {
			file.createNewFile();
		} catch (Exception e) {}

		if (!Environment.getExternalStorageState().equals(
				Environment.MEDIA_MOUNTED)) {
			return;
		}
		File sdPath = Environment.getExternalStorageDirectory();

		sdPath = new File(sdPath.getAbsolutePath() + "/Alternative/CFG/");
		sdPath.mkdirs();
		File sdFile = new File(sdPath, name);
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(sdFile));
			bw.write(text.trim());
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
			return;
		}
		
	}
	
	public static void DownloadFromUrl(Context ctx, String imageURL, String fileName) {  //this is the downloader method
		try {

			URL url = new URL(imageURL); //you can write here any link
			File file = new File(ctx.getFilesDir().getPath().toString(),fileName);
			
			long startTime = System.currentTimeMillis();
			
			URLConnection ucon = url.openConnection();
			
            InputStream is = ucon.getInputStream();
            BufferedInputStream bis = new BufferedInputStream(is);
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            
            byte[] data = new byte[50];
            int current = 0;

            while ((current = bis.read(data, 0, data.length)) != -1) {
                buffer.write(data, 0, current);
            }

            FileOutputStream fos = new FileOutputStream(file);
            fos.write(buffer.toByteArray());
            fos.close();
		} catch (IOException e) {
			Utils.log(ctx, e.toString());
		}

	}
	
	public static void loadImageFromUrl(ImageView img, String link) {
		try {
			URL url = new URL(link);
			try {
				Bitmap bmp = BitmapFactory.decodeStream(url.openConnection().getInputStream());
				img.setImageBitmap(bmp);
			} catch (IOException e) {}
		} catch (MalformedURLException e) {}
		
	}
	
	public static String getHwid(Context ctx) {
		return Secure.getString(ctx.getContentResolver(), Secure.ANDROID_ID); 
	}
	
	public static String getUser(Context ctx) {
		String hwid = getHwid(ctx);
		String androidid = Build.VERSION.RELEASE;
		String manufacter = System.getProperty("ro.product.system.manufacturer");
		String user = Build.USER;
		String host = Build.HOST;
		String brand = Build.BRAND;
		
		String heading = "|" + hwid + "|";
		return heading;
	}
	
	public static void initRequest() {
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		StrictMode.setThreadPolicy(policy);
	}
	
	public static void SetAssets(Context ctx, ImageView img, String path) {
		try {
			InputStream ims = ctx.getAssets().open(path);
			Drawable d = Drawable.createFromStream(ims, null);
			img.setImageDrawable(d);
			ims .close();
		}
		catch(IOException ex) {return;}
	}
	
	public static Typeface font(Context ctx) {
		return Typeface.createFromAsset(ctx.getAssets(), "Font.ttf");
	}
	
	public static int dp(Context context, float dp)
	{
		float scale = context.getResources().getDisplayMetrics().density;
		return (int) (dp * scale);
	}
	
	public static int pd(Context context, float dp) {
		float scale = context.getResources().getDisplayMetrics().density;
		return (int) (dp / scale);
	}
	
	public static String getDp(Context ctx, int val) {
		int value = 0;
		if (0 < val) {
			value = pd(ctx, val);
		} else {
			value = val;
		}
		String value2 = Integer.toString(value) + "dp";
		if (val == -1) value2 = "MATCH_PARENT";
		if (val == -2) value2 = "WRAP_CONTENT";
		
		return value2;
	}
	
	public static String urlRequest(String str) {

		StringBuilder sb = new StringBuilder();
        try {

            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new URL(str).openConnection().getInputStream()));
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    break;
                }
                sb.append(readLine);
                sb.append("\n");
            }
            bufferedReader.close();
        } catch (Exception e) {
            return e.toString();
        }
        return sb.toString().trim();
    }
	
	public static void urlRequestPost(String link, String data) {
		try {
			String postData = data;
			URL url = new URL(link);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setUseCaches(false);
			connection.setDoInput(true);
			connection.setDoOutput(true);
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Content-Type", "text/plain");
			//connection.setRequestProperty("Content-Length", "5500");
			// Write data
			OutputStream os = connection.getOutputStream();
			os.write(postData.getBytes());
			// Read response
			StringBuilder responseSB = new StringBuilder();
			BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		} catch (Exception e) {
			
		}
	}
	
	public static void anim(View v, int time) {
		ObjectAnimator animation = ObjectAnimator.ofFloat(v, "alpha", 0, 1.0f);
		animation.setDuration(time);
		animation.start();
	}
	
	public static void disanim(View v, int time) {
		ObjectAnimator animation = ObjectAnimator.ofFloat(v, "alpha", 1.0f, 0);
		animation.setDuration(time);
		animation.start();
	}
	
	public static String getFileExtension(File file) {
        String fileName = file.getName();
        if(fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0)
        	return fileName.substring(fileName.lastIndexOf(".")+1);
        else return "";
    }
	
	public static void log(Context ctx, String t) {
		Toast.makeText(ctx, t, 1).show();
	}
	
	public static String readFromFile(Context contect, File myFile) {
		String aBuffer = "";
		try {
			FileInputStream fIn = new FileInputStream(myFile);
			BufferedReader myReader = new BufferedReader(new InputStreamReader(fIn));
			String aDataRow = "";
			while ((aDataRow = myReader.readLine()) != null) {
				aBuffer += aDataRow + "\n";
			}
			myReader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return aBuffer;
	}
}
